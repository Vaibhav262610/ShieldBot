(()=>{var e={};e.id=974,e.ids=[974],e.modules={10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},19121:e=>{"use strict";e.exports=require("next/dist/server/app-render/action-async-storage.external.js")},3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},33873:e=>{"use strict";e.exports=require("path")},79551:e=>{"use strict";e.exports=require("url")},1777:(e,t,r)=>{"use strict";r.r(t),r.d(t,{GlobalError:()=>o.a,__next_app__:()=>f,pages:()=>d,routeModule:()=>m,tree:()=>c});var a=r(70260),n=r(28203),s=r(25155),o=r.n(s),i=r(67292),l={};for(let e in i)0>["default","tree","pages","GlobalError","__next_app__","routeModule"].indexOf(e)&&(l[e]=()=>i[e]);r.d(t,l);let c=["",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(r.bind(r,24134)),"D:\\VAIBHAV\\shieldbot\\src\\app\\page.js"],metadata:{icon:[async e=>(await Promise.resolve().then(r.bind(r,70440))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}]},{layout:[()=>Promise.resolve().then(r.bind(r,62804)),"D:\\VAIBHAV\\shieldbot\\src\\app\\layout.js"],"not-found":[()=>Promise.resolve().then(r.t.bind(r,19937,23)),"next/dist/client/components/not-found-error"],forbidden:[()=>Promise.resolve().then(r.t.bind(r,69116,23)),"next/dist/client/components/forbidden-error"],unauthorized:[()=>Promise.resolve().then(r.t.bind(r,41485,23)),"next/dist/client/components/unauthorized-error"],metadata:{icon:[async e=>(await Promise.resolve().then(r.bind(r,70440))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}],d=["D:\\VAIBHAV\\shieldbot\\src\\app\\page.js"],f={require:r,loadChunk:()=>Promise.resolve()},m=new a.AppPageRouteModule({definition:{kind:n.RouteKind.APP_PAGE,page:"/page",pathname:"/",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:c}})},33734:(e,t,r)=>{Promise.resolve().then(r.t.bind(r,13219,23)),Promise.resolve().then(r.t.bind(r,34863,23)),Promise.resolve().then(r.t.bind(r,25155,23)),Promise.resolve().then(r.t.bind(r,40802,23)),Promise.resolve().then(r.t.bind(r,9350,23)),Promise.resolve().then(r.t.bind(r,48530,23)),Promise.resolve().then(r.t.bind(r,88921,23))},3470:(e,t,r)=>{Promise.resolve().then(r.t.bind(r,66959,23)),Promise.resolve().then(r.t.bind(r,33875,23)),Promise.resolve().then(r.t.bind(r,88903,23)),Promise.resolve().then(r.t.bind(r,57174,23)),Promise.resolve().then(r.t.bind(r,84178,23)),Promise.resolve().then(r.t.bind(r,87190,23)),Promise.resolve().then(r.t.bind(r,61365,23))},62273:(e,t,r)=>{Promise.resolve().then(r.bind(r,39454))},75425:(e,t,r)=>{Promise.resolve().then(r.bind(r,5698))},52854:(e,t,r)=>{Promise.resolve().then(r.bind(r,99423)),Promise.resolve().then(r.bind(r,72322)),Promise.resolve().then(r.bind(r,59516)),Promise.resolve().then(r.bind(r,95797)),Promise.resolve().then(r.bind(r,54179)),Promise.resolve().then(r.bind(r,98436))},76414:(e,t,r)=>{Promise.resolve().then(r.bind(r,62619)),Promise.resolve().then(r.bind(r,54046)),Promise.resolve().then(r.bind(r,95625)),Promise.resolve().then(r.bind(r,37892)),Promise.resolve().then(r.bind(r,54087)),Promise.resolve().then(r.bind(r,29008))},2834:(e,t,r)=>{"use strict";var a=r(57971),n={childContextTypes:!0,contextType:!0,contextTypes:!0,defaultProps:!0,displayName:!0,getDefaultProps:!0,getDerivedStateFromError:!0,getDerivedStateFromProps:!0,mixins:!0,propTypes:!0,type:!0},s={name:!0,length:!0,prototype:!0,caller:!0,callee:!0,arguments:!0,arity:!0},o={$$typeof:!0,compare:!0,defaultProps:!0,displayName:!0,propTypes:!0,type:!0},i={};function l(e){return a.isMemo(e)?o:i[e.$$typeof]||n}i[a.ForwardRef]={$$typeof:!0,render:!0,defaultProps:!0,displayName:!0,propTypes:!0},i[a.Memo]=o;var c=Object.defineProperty,d=Object.getOwnPropertyNames,f=Object.getOwnPropertySymbols,m=Object.getOwnPropertyDescriptor,u=Object.getPrototypeOf,p=Object.prototype;e.exports=function e(t,r,a){if("string"!=typeof r){if(p){var n=u(r);n&&n!==p&&e(t,n,a)}var o=d(r);f&&(o=o.concat(f(r)));for(var i=l(t),h=l(r),x=0;x<o.length;++x){var y=o[x];if(!s[y]&&!(a&&a[y])&&!(h&&h[y])&&!(i&&i[y])){var g=m(r,y);try{c(t,y,g)}catch(e){}}}}return t}},17902:(e,t)=>{"use strict";var r=Symbol.for("react.element"),a=Symbol.for("react.portal"),n=Symbol.for("react.fragment"),s=Symbol.for("react.strict_mode"),o=Symbol.for("react.profiler"),i=Symbol.for("react.provider"),l=Symbol.for("react.context"),c=Symbol.for("react.server_context"),d=Symbol.for("react.forward_ref"),f=Symbol.for("react.suspense"),m=Symbol.for("react.suspense_list"),u=Symbol.for("react.memo"),p=Symbol.for("react.lazy");Symbol.for("react.offscreen"),Symbol.for("react.module.reference"),t.isFragment=function(e){return function(e){if("object"==typeof e&&null!==e){var t=e.$$typeof;switch(t){case r:switch(e=e.type){case n:case o:case s:case f:case m:return e;default:switch(e=e&&e.$$typeof){case c:case l:case d:case p:case u:case i:return e;default:return t}}case a:return t}}}(e)===n}},91186:(e,t,r)=>{"use strict";e.exports=r(17902)},62407:(e,t)=>{"use strict";var r="function"==typeof Symbol&&Symbol.for,a=r?Symbol.for("react.element"):60103,n=r?Symbol.for("react.portal"):60106,s=r?Symbol.for("react.fragment"):60107,o=r?Symbol.for("react.strict_mode"):60108,i=r?Symbol.for("react.profiler"):60114,l=r?Symbol.for("react.provider"):60109,c=r?Symbol.for("react.context"):60110,d=r?Symbol.for("react.async_mode"):60111,f=r?Symbol.for("react.concurrent_mode"):60111,m=r?Symbol.for("react.forward_ref"):60112,u=r?Symbol.for("react.suspense"):60113,p=r?Symbol.for("react.suspense_list"):60120,h=r?Symbol.for("react.memo"):60115,x=r?Symbol.for("react.lazy"):60116,y=r?Symbol.for("react.block"):60121,g=r?Symbol.for("react.fundamental"):60117,b=r?Symbol.for("react.responder"):60118,v=r?Symbol.for("react.scope"):60119;function w(e){if("object"==typeof e&&null!==e){var t=e.$$typeof;switch(t){case a:switch(e=e.type){case d:case f:case s:case i:case o:case u:return e;default:switch(e=e&&e.$$typeof){case c:case m:case x:case h:case l:return e;default:return t}}case n:return t}}}function j(e){return w(e)===f}t.AsyncMode=d,t.ConcurrentMode=f,t.ContextConsumer=c,t.ContextProvider=l,t.Element=a,t.ForwardRef=m,t.Fragment=s,t.Lazy=x,t.Memo=h,t.Portal=n,t.Profiler=i,t.StrictMode=o,t.Suspense=u,t.isAsyncMode=function(e){return j(e)||w(e)===d},t.isConcurrentMode=j,t.isContextConsumer=function(e){return w(e)===c},t.isContextProvider=function(e){return w(e)===l},t.isElement=function(e){return"object"==typeof e&&null!==e&&e.$$typeof===a},t.isForwardRef=function(e){return w(e)===m},t.isFragment=function(e){return w(e)===s},t.isLazy=function(e){return w(e)===x},t.isMemo=function(e){return w(e)===h},t.isPortal=function(e){return w(e)===n},t.isProfiler=function(e){return w(e)===i},t.isStrictMode=function(e){return w(e)===o},t.isSuspense=function(e){return w(e)===u},t.isValidElementType=function(e){return"string"==typeof e||"function"==typeof e||e===s||e===f||e===i||e===o||e===u||e===p||"object"==typeof e&&null!==e&&(e.$$typeof===x||e.$$typeof===h||e.$$typeof===l||e.$$typeof===c||e.$$typeof===m||e.$$typeof===g||e.$$typeof===b||e.$$typeof===v||e.$$typeof===y)},t.typeOf=w},57971:(e,t,r)=>{"use strict";e.exports=r(62407)},62619:(e,t,r)=>{"use strict";r.d(t,{default:()=>l});var a=r(45512),n=r(58009),s=r(4725),o=r(52414);let i=[{question:"What is ShieldBot?",answer:"ShieldBot is a cybersecurity tool that simulates real-world DDoS attacks to test and enhance website resilience."},{question:"How does ShieldBot protect my website?",answer:"ShieldBot runs controlled attack simulations, helping you identify weaknesses and implement better security measures."},{question:"Is ShieldBot safe to use?",answer:"Yes! Our tests are non-destructive and are performed only with proper authorization."},{question:"Can I customize attack simulations?",answer:"Absolutely! You can customize attack types, intensity, and duration according to your needs."},{question:"What pricing plans are available?",answer:"We offer flexible pricing plans, including free trials, monthly subscriptions, and enterprise solutions."}],l=()=>{let[e,t]=(0,n.useState)(null),r=r=>{t(e===r?null:r)};return(0,a.jsxs)("div",{id:"faq",className:"border-t border-b border-white/70 min-h-screen bg-gradient-to-b from-[#0f172a]/40 to-[#1e293b]/40 text-white flex flex-col items-center justify-center py-16 px-6",children:[(0,a.jsx)("h2",{className:"text-5xl font-bold text-blue-400 mb-12 tracking-wide",children:"Frequently Asked Questions ❓"}),(0,a.jsx)("div",{className:"w-full max-w-2xl space-y-6",children:i.map((t,n)=>(0,a.jsxs)("div",{className:"bg-[#1e293b] p-6 rounded-lg shadow-lg border border-gray-700 transition-all hover:bg-[#334155] hover:shadow-blue-500/10",children:[(0,a.jsxs)("button",{className:"flex justify-between items-center w-full text-left text-xl font-semibold text-white",onClick:()=>r(n),children:[t.question,(0,a.jsx)(o.Vr3,{className:`transform transition-transform duration-300 ${e===n?"rotate-180 text-blue-400":"text-gray-400"}`})]}),e===n&&(0,a.jsx)(s.P.p,{className:"mt-3 text-gray-300 text-lg leading-relaxed",initial:{opacity:0,height:0},animate:{opacity:1,height:"auto"},exit:{opacity:0,height:0},children:t.answer})]},n))})]})}},54046:(e,t,r)=>{"use strict";r.d(t,{default:()=>tb});var a,n=r(45512),s=r(58009),o=r(4725),i=r(94825);let l=(0,i.A)("ShieldAlert",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"M12 8v4",key:"1got3b"}],["path",{d:"M12 16h.01",key:"1drbdi"}]]),c=(0,i.A)("Globe",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20",key:"13o1zl"}],["path",{d:"M2 12h20",key:"9i4pu4"}]]),d=(0,i.A)("Activity",[["path",{d:"M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2",key:"169zse"}]]),f=(0,i.A)("ShieldCheck",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]]);var m=function(){function e(e){var t=this;this._insertTag=function(e){var r;r=0===t.tags.length?t.insertionPoint?t.insertionPoint.nextSibling:t.prepend?t.container.firstChild:t.before:t.tags[t.tags.length-1].nextSibling,t.container.insertBefore(e,r),t.tags.push(e)},this.isSpeedy=void 0===e.speedy||e.speedy,this.tags=[],this.ctr=0,this.nonce=e.nonce,this.key=e.key,this.container=e.container,this.prepend=e.prepend,this.insertionPoint=e.insertionPoint,this.before=null}var t=e.prototype;return t.hydrate=function(e){e.forEach(this._insertTag)},t.insert=function(e){if(this.ctr%(this.isSpeedy?65e3:1)==0){var t;this._insertTag(((t=document.createElement("style")).setAttribute("data-emotion",this.key),void 0!==this.nonce&&t.setAttribute("nonce",this.nonce),t.appendChild(document.createTextNode("")),t.setAttribute("data-s",""),t))}var r=this.tags[this.tags.length-1];if(this.isSpeedy){var a=function(e){if(e.sheet)return e.sheet;for(var t=0;t<document.styleSheets.length;t++)if(document.styleSheets[t].ownerNode===e)return document.styleSheets[t]}(r);try{a.insertRule(e,a.cssRules.length)}catch(e){}}else r.appendChild(document.createTextNode(e));this.ctr++},t.flush=function(){this.tags.forEach(function(e){var t;return null==(t=e.parentNode)?void 0:t.removeChild(e)}),this.tags=[],this.ctr=0},e}(),u=Math.abs,p=String.fromCharCode,h=Object.assign;function x(e,t,r){return e.replace(t,r)}function y(e,t){return e.indexOf(t)}function g(e,t){return 0|e.charCodeAt(t)}function b(e,t,r){return e.slice(t,r)}function v(e){return e.length}function w(e,t){return t.push(e),e}var j=1,k=1,N=0,S=0,C=0,P="";function A(e,t,r,a,n,s,o){return{value:e,root:t,parent:r,type:a,props:n,children:s,line:j,column:k,length:o,return:""}}function O(e,t){return h(A("",null,null,"",null,null,0),e,{length:-e.length},t)}function E(){return C=S<N?g(P,S++):0,k++,10===C&&(k=1,j++),C}function $(){return g(P,S)}function M(e){switch(e){case 0:case 9:case 10:case 13:case 32:return 5;case 33:case 43:case 44:case 47:case 62:case 64:case 126:case 59:case 123:case 125:return 4;case 58:return 3;case 34:case 39:case 40:case 91:return 2;case 41:case 93:return 1}return 0}function z(e){return j=k=1,N=v(P=e),S=0,[]}function _(e){var t,r;return(t=S-1,r=function e(t){for(;E();)switch(C){case t:return S;case 34:case 39:34!==t&&39!==t&&e(C);break;case 40:41===t&&e(t);break;case 92:E()}return S}(91===e?e+2:40===e?e+1:e),b(P,t,r)).trim()}var I="-ms-",D="-moz-",V="-webkit-",B="comm",L="rule",R="decl",Y="@keyframes";function T(e,t){for(var r="",a=e.length,n=0;n<a;n++)r+=t(e[n],n,e,t)||"";return r}function H(e,t,r,a){switch(e.type){case"@layer":if(e.children.length)break;case"@import":case R:return e.return=e.return||e.value;case B:return"";case Y:return e.return=e.value+"{"+T(e.children,a)+"}";case L:e.value=e.props.join(",")}return v(r=T(e.children,a))?e.return=e.value+"{"+r+"}":""}function X(e){var t=e.length;return function(r,a,n,s){for(var o="",i=0;i<t;i++)o+=e[i](r,a,n,s)||"";return o}}function F(e){var t;return t=function e(t,r,a,n,s,o,i,l,c){for(var d,f=0,m=0,u=i,h=0,N=0,O=0,z=1,I=1,D=1,V=0,L="",R=s,Y=o,T=n,H=L;I;)switch(O=V,V=E()){case 40:if(108!=O&&58==g(H,u-1)){-1!=y(H+=x(_(V),"&","&\f"),"&\f")&&(D=-1);break}case 34:case 39:case 91:H+=_(V);break;case 9:case 10:case 13:case 32:H+=function(e){for(;C=$();)if(C<33)E();else break;return M(e)>2||M(C)>3?"":" "}(O);break;case 92:H+=function(e,t){for(var r;--t&&E()&&!(C<48)&&!(C>102)&&(!(C>57)||!(C<65))&&(!(C>70)||!(C<97)););return r=S+(t<6&&32==$()&&32==E()),b(P,e,r)}(S-1,7);continue;case 47:switch($()){case 42:case 47:w(A(d=function(e,t){for(;E();)if(e+C===57)break;else if(e+C===84&&47===$())break;return"/*"+b(P,t,S-1)+"*"+p(47===e?e:E())}(E(),S),r,a,B,p(C),b(d,2,-2),0),c);break;default:H+="/"}break;case 123*z:l[f++]=v(H)*D;case 125*z:case 59:case 0:switch(V){case 0:case 125:I=0;case 59+m:-1==D&&(H=x(H,/\f/g,"")),N>0&&v(H)-u&&w(N>32?G(H+";",n,a,u-1):G(x(H," ","")+";",n,a,u-2),c);break;case 59:H+=";";default:if(w(T=q(H,r,a,f,m,s,l,L,R=[],Y=[],u),o),123===V){if(0===m)e(H,r,T,T,R,o,u,l,Y);else switch(99===h&&110===g(H,3)?100:h){case 100:case 108:case 109:case 115:e(t,T,T,n&&w(q(t,T,T,0,0,s,l,L,s,R=[],u),Y),s,Y,u,l,n?R:Y);break;default:e(H,T,T,T,[""],Y,0,l,Y)}}}f=m=N=0,z=D=1,L=H="",u=i;break;case 58:u=1+v(H),N=O;default:if(z<1){if(123==V)--z;else if(125==V&&0==z++&&125==(C=S>0?g(P,--S):0,k--,10===C&&(k=1,j--),C))continue}switch(H+=p(V),V*z){case 38:D=m>0?1:(H+="\f",-1);break;case 44:l[f++]=(v(H)-1)*D,D=1;break;case 64:45===$()&&(H+=_(E())),h=$(),m=u=v(L=H+=function(e){for(;!M($());)E();return b(P,e,S)}(S)),V++;break;case 45:45===O&&2==v(H)&&(z=0)}}return o}("",null,null,null,[""],e=z(e),0,[0],e),P="",t}function q(e,t,r,a,n,s,o,i,l,c,d){for(var f=n-1,m=0===n?s:[""],p=m.length,h=0,y=0,g=0;h<a;++h)for(var v=0,w=b(e,f+1,f=u(y=o[h])),j=e;v<p;++v)(j=(y>0?m[v]+" "+w:x(w,/&\f/g,m[v])).trim())&&(l[g++]=j);return A(e,t,r,0===n?L:i,l,c,d)}function G(e,t,r,a){return A(e,t,r,R,b(e,0,a),b(e,a+1,-1),a)}function W(e){var t=Object.create(null);return function(r){return void 0===t[r]&&(t[r]=e(r)),t[r]}}var U="undefined"!=typeof document,Q=function(e,t,r){for(var a=0,n=0;a=n,n=$(),38===a&&12===n&&(t[r]=1),!M(n);)E();return b(P,e,S)},J=function(e,t){var r=-1,a=44;do switch(M(a)){case 0:38===a&&12===$()&&(t[r]=1),e[r]+=Q(S-1,t,r);break;case 2:e[r]+=_(a);break;case 4:if(44===a){e[++r]=58===$()?"&\f":"",t[r]=e[r].length;break}default:e[r]+=p(a)}while(a=E());return e},Z=function(e,t){var r;return r=J(z(e),t),P="",r},K=new WeakMap,ee=function(e){if("rule"===e.type&&e.parent&&!(e.length<1)){for(var t=e.value,r=e.parent,a=e.column===r.column&&e.line===r.line;"rule"!==r.type;)if(!(r=r.parent))return;if((1!==e.props.length||58===t.charCodeAt(0)||K.get(r))&&!a){K.set(e,!0);for(var n=[],s=Z(t,n),o=r.props,i=0,l=0;i<s.length;i++)for(var c=0;c<o.length;c++,l++)e.props[l]=n[i]?s[i].replace(/&\f/g,o[c]):o[c]+" "+s[i]}}},et=function(e){if("decl"===e.type){var t=e.value;108===t.charCodeAt(0)&&98===t.charCodeAt(2)&&(e.return="",e.value="")}},er=U?void 0:function(e){var t=new WeakMap;return function(r){if(t.has(r))return t.get(r);var a=e(r);return t.set(r,a),a}}(function(){return W(function(){return{}})}),ea=[function(e,t,r,a){if(e.length>-1&&!e.return)switch(e.type){case R:e.return=function e(t,r){switch(45^g(t,0)?(((r<<2^g(t,0))<<2^g(t,1))<<2^g(t,2))<<2^g(t,3):0){case 5103:return V+"print-"+t+t;case 5737:case 4201:case 3177:case 3433:case 1641:case 4457:case 2921:case 5572:case 6356:case 5844:case 3191:case 6645:case 3005:case 6391:case 5879:case 5623:case 6135:case 4599:case 4855:case 4215:case 6389:case 5109:case 5365:case 5621:case 3829:return V+t+t;case 5349:case 4246:case 4810:case 6968:case 2756:return V+t+D+t+I+t+t;case 6828:case 4268:return V+t+I+t+t;case 6165:return V+t+I+"flex-"+t+t;case 5187:return V+t+x(t,/(\w+).+(:[^]+)/,V+"box-$1$2"+I+"flex-$1$2")+t;case 5443:return V+t+I+"flex-item-"+x(t,/flex-|-self/,"")+t;case 4675:return V+t+I+"flex-line-pack"+x(t,/align-content|flex-|-self/,"")+t;case 5548:return V+t+I+x(t,"shrink","negative")+t;case 5292:return V+t+I+x(t,"basis","preferred-size")+t;case 6060:return V+"box-"+x(t,"-grow","")+V+t+I+x(t,"grow","positive")+t;case 4554:return V+x(t,/([^-])(transform)/g,"$1"+V+"$2")+t;case 6187:return x(x(x(t,/(zoom-|grab)/,V+"$1"),/(image-set)/,V+"$1"),t,"")+t;case 5495:case 3959:return x(t,/(image-set\([^]*)/,V+"$1$`$1");case 4968:return x(x(t,/(.+:)(flex-)?(.*)/,V+"box-pack:$3"+I+"flex-pack:$3"),/s.+-b[^;]+/,"justify")+V+t+t;case 4095:case 3583:case 4068:case 2532:return x(t,/(.+)-inline(.+)/,V+"$1$2")+t;case 8116:case 7059:case 5753:case 5535:case 5445:case 5701:case 4933:case 4677:case 5533:case 5789:case 5021:case 4765:if(v(t)-1-r>6)switch(g(t,r+1)){case 109:if(45!==g(t,r+4))break;case 102:return x(t,/(.+:)(.+)-([^]+)/,"$1"+V+"$2-$3$1"+D+(108==g(t,r+3)?"$3":"$2-$3"))+t;case 115:return~y(t,"stretch")?e(x(t,"stretch","fill-available"),r)+t:t}break;case 4949:if(115!==g(t,r+1))break;case 6444:switch(g(t,v(t)-3-(~y(t,"!important")&&10))){case 107:return x(t,":",":"+V)+t;case 101:return x(t,/(.+:)([^;!]+)(;|!.+)?/,"$1"+V+(45===g(t,14)?"inline-":"")+"box$3$1"+V+"$2$3$1"+I+"$2box$3")+t}break;case 5936:switch(g(t,r+11)){case 114:return V+t+I+x(t,/[svh]\w+-[tblr]{2}/,"tb")+t;case 108:return V+t+I+x(t,/[svh]\w+-[tblr]{2}/,"tb-rl")+t;case 45:return V+t+I+x(t,/[svh]\w+-[tblr]{2}/,"lr")+t}return V+t+I+t+t}return t}(e.value,e.length);break;case Y:return T([O(e,{value:x(e.value,"@","@"+V)})],a);case L:if(e.length){var n,s;return n=e.props,s=function(t){var r;switch(r=t,(r=/(::plac\w+|:read-\w+)/.exec(r))?r[0]:r){case":read-only":case":read-write":return T([O(e,{props:[x(t,/:(read-\w+)/,":"+D+"$1")]})],a);case"::placeholder":return T([O(e,{props:[x(t,/:(plac\w+)/,":"+V+"input-$1")]}),O(e,{props:[x(t,/:(plac\w+)/,":"+D+"$1")]}),O(e,{props:[x(t,/:(plac\w+)/,I+"input-$1")]})],a)}return""},n.map(s).join("")}}}],en=function(e){var t=e.key;if(U&&"css"===t){var r=document.querySelectorAll("style[data-emotion]:not([data-s])");Array.prototype.forEach.call(r,function(e){-1!==e.getAttribute("data-emotion").indexOf(" ")&&(document.head.appendChild(e),e.setAttribute("data-s",""))})}var a=e.stylisPlugins||ea,n={},s=[];U&&(f=e.container||document.head,Array.prototype.forEach.call(document.querySelectorAll('style[data-emotion^="'+t+' "]'),function(e){for(var t=e.getAttribute("data-emotion").split(" "),r=1;r<t.length;r++)n[t[r]]=!0;s.push(e)}));var o=[ee,et];if(er){var i=X(o.concat(a,[H])),l=er(a)(t),c=function(e,t){var r=t.name;return void 0===l[r]&&(l[r]=T(F(e?e+"{"+t.styles+"}":t.styles),i)),l[r]};u=function(e,t,r,a){var n=t.name,s=c(e,t);return void 0===y.compat?(a&&(y.inserted[n]=!0),s):a?void(y.inserted[n]=s):s}}else{var d,f,u,p,h=[H,(d=function(e){p.insert(e)},function(e){!e.root&&(e=e.return)&&d(e)})],x=X(o.concat(a,h));u=function(e,t,r,a){p=r,T(F(e?e+"{"+t.styles+"}":t.styles),x),a&&(y.inserted[t.name]=!0)}}var y={key:t,sheet:new m({key:t,container:f,nonce:e.nonce,speedy:e.speedy,prepend:e.prepend,insertionPoint:e.insertionPoint}),nonce:e.nonce,inserted:n,registered:{},insert:u};return y.sheet.hydrate(s),y},es="undefined"!=typeof document;function eo(e,t,r){var a="";return r.split(" ").forEach(function(r){void 0!==e[r]?t.push(e[r]+";"):r&&(a+=r+" ")}),a}var ei=function(e,t,r){var a=e.key+"-"+t.name;(!1===r||!1===es&&void 0!==e.compat)&&void 0===e.registered[a]&&(e.registered[a]=t.styles)},el=function(e,t,r){ei(e,t,r);var a=e.key+"-"+t.name;if(void 0===e.inserted[t.name]){var n="",s=t;do{var o=e.insert(t===s?"."+a:"",s,e.sheet,!0);es||void 0===o||(n+=o),s=s.next}while(void 0!==s);if(!es&&0!==n.length)return n}},ec={animationIterationCount:1,aspectRatio:1,borderImageOutset:1,borderImageSlice:1,borderImageWidth:1,boxFlex:1,boxFlexGroup:1,boxOrdinalGroup:1,columnCount:1,columns:1,flex:1,flexGrow:1,flexPositive:1,flexShrink:1,flexNegative:1,flexOrder:1,gridRow:1,gridRowEnd:1,gridRowSpan:1,gridRowStart:1,gridColumn:1,gridColumnEnd:1,gridColumnSpan:1,gridColumnStart:1,msGridRow:1,msGridRowSpan:1,msGridColumn:1,msGridColumnSpan:1,fontWeight:1,lineHeight:1,opacity:1,order:1,orphans:1,scale:1,tabSize:1,widows:1,zIndex:1,zoom:1,WebkitLineClamp:1,fillOpacity:1,floodOpacity:1,stopOpacity:1,strokeDasharray:1,strokeDashoffset:1,strokeMiterlimit:1,strokeOpacity:1,strokeWidth:1},ed=/[A-Z]|^ms/g,ef=/_EMO_([^_]+?)_([^]*?)_EMO_/g,em=function(e){return 45===e.charCodeAt(1)},eu=function(e){return null!=e&&"boolean"!=typeof e},ep=W(function(e){return em(e)?e:e.replace(ed,"-$&").toLowerCase()}),eh=function(e,t){switch(e){case"animation":case"animationName":if("string"==typeof t)return t.replace(ef,function(e,t,r){return a={name:t,styles:r,next:a},t})}return 1===ec[e]||em(e)||"number"!=typeof t||0===t?t:t+"px"};function ex(e,t,r){if(null==r)return"";if(void 0!==r.__emotion_styles)return r;switch(typeof r){case"boolean":return"";case"object":if(1===r.anim)return a={name:r.name,styles:r.styles,next:a},r.name;if(void 0!==r.styles){var n=r.next;if(void 0!==n)for(;void 0!==n;)a={name:n.name,styles:n.styles,next:a},n=n.next;return r.styles+";"}return function(e,t,r){var a="";if(Array.isArray(r))for(var n=0;n<r.length;n++)a+=ex(e,t,r[n])+";";else for(var s in r){var o=r[s];if("object"!=typeof o)null!=t&&void 0!==t[o]?a+=s+"{"+t[o]+"}":eu(o)&&(a+=ep(s)+":"+eh(s,o)+";");else if(Array.isArray(o)&&"string"==typeof o[0]&&(null==t||void 0===t[o[0]]))for(var i=0;i<o.length;i++)eu(o[i])&&(a+=ep(s)+":"+eh(s,o[i])+";");else{var l=ex(e,t,o);switch(s){case"animation":case"animationName":a+=ep(s)+":"+l+";";break;default:a+=s+"{"+l+"}"}}}return a}(e,t,r);case"function":if(void 0!==e){var s=a,o=r(e);return a=s,ex(e,t,o)}}if(null==t)return r;var i=t[r];return void 0!==i?i:r}var ey=/label:\s*([^\s;{]+)\s*(;|$)/g;function eg(e,t,r){if(1===e.length&&"object"==typeof e[0]&&null!==e[0]&&void 0!==e[0].styles)return e[0];var n,s=!0,o="";a=void 0;var i=e[0];null==i||void 0===i.raw?(s=!1,o+=ex(r,t,i)):o+=i[0];for(var l=1;l<e.length;l++)o+=ex(r,t,e[l]),s&&(o+=i[l]);ey.lastIndex=0;for(var c="";null!==(n=ey.exec(o));)c+="-"+n[1];return{name:function(e){for(var t,r=0,a=0,n=e.length;n>=4;++a,n-=4)t=(65535&(t=255&e.charCodeAt(a)|(255&e.charCodeAt(++a))<<8|(255&e.charCodeAt(++a))<<16|(255&e.charCodeAt(++a))<<24))*0x5bd1e995+((t>>>16)*59797<<16),t^=t>>>24,r=(65535&t)*0x5bd1e995+((t>>>16)*59797<<16)^(65535&r)*0x5bd1e995+((r>>>16)*59797<<16);switch(n){case 3:r^=(255&e.charCodeAt(a+2))<<16;case 2:r^=(255&e.charCodeAt(a+1))<<8;case 1:r^=255&e.charCodeAt(a),r=(65535&r)*0x5bd1e995+((r>>>16)*59797<<16)}return r^=r>>>13,(((r=(65535&r)*0x5bd1e995+((r>>>16)*59797<<16))^r>>>15)>>>0).toString(36)}(o)+c,styles:o,next:a}}var eb="undefined"!=typeof document,ev=!!s.useInsertionEffect&&s.useInsertionEffect,ew=eb&&ev||function(e){return e()};ev||s.useLayoutEffect;var ej="undefined"!=typeof document,ek=s.createContext("undefined"!=typeof HTMLElement?en({key:"css"}):null);ek.Provider;var eN=function(e){return(0,s.forwardRef)(function(t,r){return e(t,(0,s.useContext)(ek),r)})};ej||(eN=function(e){return function(t){var r=(0,s.useContext)(ek);return null===r?(r=en({key:"css"}),s.createElement(ek.Provider,{value:r},e(t,r))):e(t,r)}});var eS=s.createContext({}),eC={}.hasOwnProperty,eP="__EMOTION_TYPE_PLEASE_DO_NOT_USE__",eA=function(e,t){var r={};for(var a in t)eC.call(t,a)&&(r[a]=t[a]);return r[eP]=e,r},eO=function(e){var t=e.cache,r=e.serialized,a=e.isStringTag;ei(t,r,a);var n=ew(function(){return el(t,r,a)});if(!ej&&void 0!==n){for(var o,i=r.name,l=r.next;void 0!==l;)i+=" "+l.name,l=l.next;return s.createElement("style",((o={})["data-emotion"]=t.key+" "+i,o.dangerouslySetInnerHTML={__html:n},o.nonce=t.sheet.nonce,o))}return null},eE=eN(function(e,t,r){var a=e.css;"string"==typeof a&&void 0!==t.registered[a]&&(a=t.registered[a]);var n=e[eP],o=[a],i="";"string"==typeof e.className?i=eo(t.registered,o,e.className):null!=e.className&&(i=e.className+" ");var l=eg(o,void 0,s.useContext(eS));i+=t.key+"-"+l.name;var c={};for(var d in e)eC.call(e,d)&&"css"!==d&&d!==eP&&(c[d]=e[d]);return c.className=i,r&&(c.ref=r),s.createElement(s.Fragment,null,s.createElement(eO,{cache:t,serialized:l,isStringTag:"string"==typeof n}),s.createElement(n,c))});r(29517),r(2834);var e$=n.Fragment,eM=function(e,t,r){return eC.call(t,"css")?n.jsx(eE,eA(e,t),r):n.jsx(e,t,r)},ez=function(e,t){var r=arguments;if(null==t||!eC.call(t,"css"))return s.createElement.apply(void 0,r);var a=r.length,n=Array(a);n[0]=eE,n[1]=eA(e,t);for(var o=2;o<a;o++)n[o]=r[o];return s.createElement.apply(null,n)};function e_(){for(var e=arguments.length,t=Array(e),r=0;r<e;r++)t[r]=arguments[r];return eg(t)}function eI(){var e=e_.apply(void 0,arguments),t="animation-"+e.name;return{name:t,styles:"@keyframes "+t+"{"+e.styles+"}",anim:1,toString:function(){return"_EMO_"+this.name+"_"+this.styles+"_EMO_"}}}!function(e){var t;t||(t=e.JSX||(e.JSX={}))}(ez||(ez={}));var eD=function e(t){for(var r=t.length,a=0,n="";a<r;a++){var s=t[a];if(null!=s){var o=void 0;switch(typeof s){case"boolean":break;case"object":if(Array.isArray(s))o=e(s);else for(var i in o="",s)s[i]&&i&&(o&&(o+=" "),o+=i);break;default:o=s}o&&(n&&(n+=" "),n+=o)}}return n},eV=function(e){var t,r=e.cache,a=e.serializedArr,n=ew(function(){for(var e="",t=0;t<a.length;t++){var n=el(r,a[t],!1);ej||void 0===n||(e+=n)}if(!ej)return e});return ej||0===n.length?null:s.createElement("style",((t={})["data-emotion"]=r.key+" "+a.map(function(e){return e.name}).join(" "),t.dangerouslySetInnerHTML={__html:n},t.nonce=r.sheet.nonce,t))},eB=eN(function(e,t){var r=[],a=function(){for(var e=arguments.length,a=Array(e),n=0;n<e;n++)a[n]=arguments[n];var s=eg(a,t.registered);return r.push(s),ei(t,s,!1),t.key+"-"+s.name},n={css:a,cx:function(){for(var e,r,n,s=arguments.length,o=Array(s),i=0;i<s;i++)o[i]=arguments[i];return n=eo(t.registered,r=[],e=eD(o)),r.length<2?e:n+a(r)},theme:s.useContext(eS)},o=e.children(n);return s.createElement(s.Fragment,null,s.createElement(eV,{cache:t,serializedArr:r}),o)}),eL=Object.defineProperty,eR=(e,t,r)=>t in e?eL(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,eY=(e,t,r)=>eR(e,"symbol"!=typeof t?t+"":t,r),eT=new Map,eH=new WeakMap,eX=0,eF=void 0;function eq(e,t,r={},a=eF){if(void 0===window.IntersectionObserver&&void 0!==a){let n=e.getBoundingClientRect();return t(a,{isIntersecting:a,target:e,intersectionRatio:"number"==typeof r.threshold?r.threshold:0,time:0,boundingClientRect:n,intersectionRect:n,rootBounds:n}),()=>{}}let{id:n,observer:s,elements:o}=function(e){let t=Object.keys(e).sort().filter(t=>void 0!==e[t]).map(t=>{var r;return`${t}_${"root"===t?(r=e.root)?(eH.has(r)||(eX+=1,eH.set(r,eX.toString())),eH.get(r)):"0":e[t]}`}).toString(),r=eT.get(t);if(!r){let a;let n=new Map,s=new IntersectionObserver(t=>{t.forEach(t=>{var r;let s=t.isIntersecting&&a.some(e=>t.intersectionRatio>=e);e.trackVisibility&&void 0===t.isVisible&&(t.isVisible=s),null==(r=n.get(t.target))||r.forEach(e=>{e(s,t)})})},e);a=s.thresholds||(Array.isArray(e.threshold)?e.threshold:[e.threshold||0]),r={id:t,observer:s,elements:n},eT.set(t,r)}return r}(r),i=o.get(e)||[];return o.has(e)||o.set(e,i),i.push(t),s.observe(e),function(){i.splice(i.indexOf(t),1),0===i.length&&(o.delete(e),s.unobserve(e)),0===o.size&&(s.disconnect(),eT.delete(n))}}var eG=class extends s.Component{constructor(e){super(e),eY(this,"node",null),eY(this,"_unobserveCb",null),eY(this,"handleNode",e=>{!this.node||(this.unobserve(),e||this.props.triggerOnce||this.props.skip||this.setState({inView:!!this.props.initialInView,entry:void 0})),this.node=e||null,this.observeNode()}),eY(this,"handleChange",(e,t)=>{e&&this.props.triggerOnce&&this.unobserve(),"function"!=typeof this.props.children||this.setState({inView:e,entry:t}),this.props.onChange&&this.props.onChange(e,t)}),this.state={inView:!!e.initialInView,entry:void 0}}componentDidMount(){this.unobserve(),this.observeNode()}componentDidUpdate(e){(e.rootMargin!==this.props.rootMargin||e.root!==this.props.root||e.threshold!==this.props.threshold||e.skip!==this.props.skip||e.trackVisibility!==this.props.trackVisibility||e.delay!==this.props.delay)&&(this.unobserve(),this.observeNode())}componentWillUnmount(){this.unobserve()}observeNode(){if(!this.node||this.props.skip)return;let{threshold:e,root:t,rootMargin:r,trackVisibility:a,delay:n,fallbackInView:s}=this.props;this._unobserveCb=eq(this.node,this.handleChange,{threshold:e,root:t,rootMargin:r,trackVisibility:a,delay:n},s)}unobserve(){this._unobserveCb&&(this._unobserveCb(),this._unobserveCb=null)}render(){let{children:e}=this.props;if("function"==typeof e){let{inView:t,entry:r}=this.state;return e({inView:t,entry:r,ref:this.handleNode})}let{as:t,triggerOnce:r,threshold:a,root:n,rootMargin:o,onChange:i,skip:l,trackVisibility:c,delay:d,initialInView:f,fallbackInView:m,...u}=this.props;return s.createElement(t||"div",{ref:this.handleNode,...u},e)}};function eW({threshold:e,delay:t,trackVisibility:r,rootMargin:a,root:n,triggerOnce:o,skip:i,initialInView:l,fallbackInView:c,onChange:d}={}){var f;let[m,u]=s.useState(null),p=s.useRef(d),[h,x]=s.useState({inView:!!l,entry:void 0});p.current=d,s.useEffect(()=>{let s;if(!i&&m)return s=eq(m,(e,t)=>{x({inView:e,entry:t}),p.current&&p.current(e,t),t.isIntersecting&&o&&s&&(s(),s=void 0)},{root:n,rootMargin:a,threshold:e,trackVisibility:r,delay:t},c),()=>{s&&s()}},[Array.isArray(e)?e.toString():e,m,n,a,o,i,r,c,t]);let y=null==(f=h.entry)?void 0:f.target,g=s.useRef(void 0);m||!y||o||i||g.current===y||(g.current=y,x({inView:!!l,entry:void 0}));let b=[u,h.inView,h.entry];return b.ref=b[0],b.inView=b[1],b.entry=b[2],b}var eU=r(91186);eI`
  from,
  20%,
  53%,
  to {
    animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
    transform: translate3d(0, 0, 0);
  }

  40%,
  43% {
    animation-timing-function: cubic-bezier(0.755, 0.05, 0.855, 0.06);
    transform: translate3d(0, -30px, 0) scaleY(1.1);
  }

  70% {
    animation-timing-function: cubic-bezier(0.755, 0.05, 0.855, 0.06);
    transform: translate3d(0, -15px, 0) scaleY(1.05);
  }

  80% {
    transition-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
    transform: translate3d(0, 0, 0) scaleY(0.95);
  }

  90% {
    transform: translate3d(0, -4px, 0) scaleY(1.02);
  }
`,eI`
  from,
  50%,
  to {
    opacity: 1;
  }

  25%,
  75% {
    opacity: 0;
  }
`,eI`
  0% {
    transform: translateX(0);
  }

  6.5% {
    transform: translateX(-6px) rotateY(-9deg);
  }

  18.5% {
    transform: translateX(5px) rotateY(7deg);
  }

  31.5% {
    transform: translateX(-3px) rotateY(-5deg);
  }

  43.5% {
    transform: translateX(2px) rotateY(3deg);
  }

  50% {
    transform: translateX(0);
  }
`,eI`
  0% {
    transform: scale(1);
  }

  14% {
    transform: scale(1.3);
  }

  28% {
    transform: scale(1);
  }

  42% {
    transform: scale(1.3);
  }

  70% {
    transform: scale(1);
  }
`,eI`
  from,
  11.1%,
  to {
    transform: translate3d(0, 0, 0);
  }

  22.2% {
    transform: skewX(-12.5deg) skewY(-12.5deg);
  }

  33.3% {
    transform: skewX(6.25deg) skewY(6.25deg);
  }

  44.4% {
    transform: skewX(-3.125deg) skewY(-3.125deg);
  }

  55.5% {
    transform: skewX(1.5625deg) skewY(1.5625deg);
  }

  66.6% {
    transform: skewX(-0.78125deg) skewY(-0.78125deg);
  }

  77.7% {
    transform: skewX(0.390625deg) skewY(0.390625deg);
  }

  88.8% {
    transform: skewX(-0.1953125deg) skewY(-0.1953125deg);
  }
`,eI`
  from {
    transform: scale3d(1, 1, 1);
  }

  50% {
    transform: scale3d(1.05, 1.05, 1.05);
  }

  to {
    transform: scale3d(1, 1, 1);
  }
`,eI`
  from {
    transform: scale3d(1, 1, 1);
  }

  30% {
    transform: scale3d(1.25, 0.75, 1);
  }

  40% {
    transform: scale3d(0.75, 1.25, 1);
  }

  50% {
    transform: scale3d(1.15, 0.85, 1);
  }

  65% {
    transform: scale3d(0.95, 1.05, 1);
  }

  75% {
    transform: scale3d(1.05, 0.95, 1);
  }

  to {
    transform: scale3d(1, 1, 1);
  }
`,eI`
  from,
  to {
    transform: translate3d(0, 0, 0);
  }

  10%,
  30%,
  50%,
  70%,
  90% {
    transform: translate3d(-10px, 0, 0);
  }

  20%,
  40%,
  60%,
  80% {
    transform: translate3d(10px, 0, 0);
  }
`,eI`
  from,
  to {
    transform: translate3d(0, 0, 0);
  }

  10%,
  30%,
  50%,
  70%,
  90% {
    transform: translate3d(-10px, 0, 0);
  }

  20%,
  40%,
  60%,
  80% {
    transform: translate3d(10px, 0, 0);
  }
`,eI`
  from,
  to {
    transform: translate3d(0, 0, 0);
  }

  10%,
  30%,
  50%,
  70%,
  90% {
    transform: translate3d(0, -10px, 0);
  }

  20%,
  40%,
  60%,
  80% {
    transform: translate3d(0, 10px, 0);
  }
`,eI`
  20% {
    transform: rotate3d(0, 0, 1, 15deg);
  }

  40% {
    transform: rotate3d(0, 0, 1, -10deg);
  }

  60% {
    transform: rotate3d(0, 0, 1, 5deg);
  }

  80% {
    transform: rotate3d(0, 0, 1, -5deg);
  }

  to {
    transform: rotate3d(0, 0, 1, 0deg);
  }
`,eI`
  from {
    transform: scale3d(1, 1, 1);
  }

  10%,
  20% {
    transform: scale3d(0.9, 0.9, 0.9) rotate3d(0, 0, 1, -3deg);
  }

  30%,
  50%,
  70%,
  90% {
    transform: scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, 3deg);
  }

  40%,
  60%,
  80% {
    transform: scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, -3deg);
  }

  to {
    transform: scale3d(1, 1, 1);
  }
`,eI`
  from {
    transform: translate3d(0, 0, 0);
  }

  15% {
    transform: translate3d(-25%, 0, 0) rotate3d(0, 0, 1, -5deg);
  }

  30% {
    transform: translate3d(20%, 0, 0) rotate3d(0, 0, 1, 3deg);
  }

  45% {
    transform: translate3d(-15%, 0, 0) rotate3d(0, 0, 1, -3deg);
  }

  60% {
    transform: translate3d(10%, 0, 0) rotate3d(0, 0, 1, 2deg);
  }

  75% {
    transform: translate3d(-5%, 0, 0) rotate3d(0, 0, 1, -1deg);
  }

  to {
    transform: translate3d(0, 0, 0);
  }
`;let eQ=eI`
  from {
    opacity: 0;
  }

  to {
    opacity: 1;
  }
`,eJ=eI`
  from {
    opacity: 0;
    transform: translate3d(-100%, 100%, 0);
  }

  to {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }
`,eZ=eI`
  from {
    opacity: 0;
    transform: translate3d(100%, 100%, 0);
  }

  to {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }
`,eK=eI`
  from {
    opacity: 0;
    transform: translate3d(0, -100%, 0);
  }

  to {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }
`,e0=eI`
  from {
    opacity: 0;
    transform: translate3d(0, -2000px, 0);
  }

  to {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }
`,e1=eI`
  from {
    opacity: 0;
    transform: translate3d(-100%, 0, 0);
  }

  to {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }
`,e3=eI`
  from {
    opacity: 0;
    transform: translate3d(-2000px, 0, 0);
  }

  to {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }
`,e5=eI`
  from {
    opacity: 0;
    transform: translate3d(100%, 0, 0);
  }

  to {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }
`,e2=eI`
  from {
    opacity: 0;
    transform: translate3d(2000px, 0, 0);
  }

  to {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }
`,e4=eI`
  from {
    opacity: 0;
    transform: translate3d(-100%, -100%, 0);
  }

  to {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }
`,e6=eI`
  from {
    opacity: 0;
    transform: translate3d(100%, -100%, 0);
  }

  to {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }
`,e7=eI`
  from {
    opacity: 0;
    transform: translate3d(0, 100%, 0);
  }

  to {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }
`,e9=eI`
  from {
    opacity: 0;
    transform: translate3d(0, 2000px, 0);
  }

  to {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }
`;function e8(e){var t;return t=()=>null,r=>r?e():t()}function te(e){return e8(()=>({opacity:0}))(e)}let tt=e=>{let{cascade:t=!1,damping:r=.5,delay:a=0,duration:n=1e3,fraction:o=0,keyframes:i=e1,triggerOnce:l=!1,className:c,style:d,childClassName:f,childStyle:m,children:u,onVisibilityChange:p}=e,h=(0,s.useMemo)(()=>(function({duration:e=1e3,delay:t=0,timingFunction:r="ease",keyframes:a=e1,iterationCount:n=1}){return e_`
    animation-duration: ${e}ms;
    animation-timing-function: ${r};
    animation-delay: ${t}ms;
    animation-name: ${a};
    animation-direction: normal;
    animation-fill-mode: both;
    animation-iteration-count: ${n};

    @media (prefers-reduced-motion: reduce) {
      animation: none;
    }
  `})({keyframes:i,duration:n}),[n,i]);return void 0==u?null:!function(e){return"string"==typeof e||"number"==typeof e||"boolean"==typeof e}(u)?(0,eU.isFragment)(u)?eM(tn,{...e,animationStyles:h}):eM(e$,{children:s.Children.map(u,(i,u)=>{if(!(0,s.isValidElement)(i))return null;let x=a+(t?u*n*r:0);switch(i.type){case"ol":case"ul":return eM(eB,{children:({cx:t})=>eM(i.type,{...i.props,className:t(c,i.props.className),style:Object.assign({},d,i.props.style),children:eM(tt,{...e,children:i.props.children})})});case"li":return eM(eG,{threshold:o,triggerOnce:l,onChange:p,children:({inView:e,ref:t})=>eM(eB,{children:({cx:r})=>eM(i.type,{...i.props,ref:t,className:r(f,i.props.className),css:e8(()=>h)(e),style:Object.assign({},m,i.props.style,te(!e),{animationDelay:x+"ms"})})})});default:return eM(eG,{threshold:o,triggerOnce:l,onChange:p,children:({inView:e,ref:t})=>eM("div",{ref:t,className:c,css:e8(()=>h)(e),style:Object.assign({},d,te(!e),{animationDelay:x+"ms"}),children:eM(eB,{children:({cx:e})=>eM(i.type,{...i.props,className:e(f,i.props.className),style:Object.assign({},m,i.props.style)})})})})}})}):eM(ta,{...e,animationStyles:h,children:String(u)})},tr={display:"inline-block",whiteSpace:"pre"},ta=e=>{var t,r;let{animationStyles:a,cascade:n=!1,damping:s=.5,delay:o=0,duration:i=1e3,fraction:l=0,triggerOnce:c=!1,className:d,style:f,children:m,onVisibilityChange:u}=e,{ref:p,inView:h}=eW({triggerOnce:c,threshold:l,onChange:u});return(t=()=>eM("div",{ref:p,className:d,style:Object.assign({},f,tr),children:m.split("").map((e,t)=>eM("span",{css:e8(()=>a)(h),style:{animationDelay:o+t*i*s+"ms"},children:e},t))}),r=()=>eM(tn,{...e,children:m}),e=>e?t():r())(n)},tn=e=>{let{animationStyles:t,fraction:r=0,triggerOnce:a=!1,className:n,style:s,children:o,onVisibilityChange:i}=e,{ref:l,inView:c}=eW({triggerOnce:a,threshold:r,onChange:i});return eM("div",{ref:l,className:n,css:e8(()=>t)(c),style:Object.assign({},s,te(!c)),children:o})},ts=(eI`
  from,
  20%,
  40%,
  60%,
  80%,
  to {
    animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
  }

  0% {
    opacity: 0;
    transform: scale3d(0.3, 0.3, 0.3);
  }

  20% {
    transform: scale3d(1.1, 1.1, 1.1);
  }

  40% {
    transform: scale3d(0.9, 0.9, 0.9);
  }

  60% {
    opacity: 1;
    transform: scale3d(1.03, 1.03, 1.03);
  }

  80% {
    transform: scale3d(0.97, 0.97, 0.97);
  }

  to {
    opacity: 1;
    transform: scale3d(1, 1, 1);
  }
`,eI`
  from,
  60%,
  75%,
  90%,
  to {
    animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
  }

  0% {
    opacity: 0;
    transform: translate3d(0, -3000px, 0) scaleY(3);
  }

  60% {
    opacity: 1;
    transform: translate3d(0, 25px, 0) scaleY(0.9);
  }

  75% {
    transform: translate3d(0, -10px, 0) scaleY(0.95);
  }

  90% {
    transform: translate3d(0, 5px, 0) scaleY(0.985);
  }

  to {
    transform: translate3d(0, 0, 0);
  }
`,eI`
  from,
  60%,
  75%,
  90%,
  to {
    animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
  }

  0% {
    opacity: 0;
    transform: translate3d(-3000px, 0, 0) scaleX(3);
  }

  60% {
    opacity: 1;
    transform: translate3d(25px, 0, 0) scaleX(1);
  }

  75% {
    transform: translate3d(-10px, 0, 0) scaleX(0.98);
  }

  90% {
    transform: translate3d(5px, 0, 0) scaleX(0.995);
  }

  to {
    transform: translate3d(0, 0, 0);
  }
`,eI`
  from,
  60%,
  75%,
  90%,
  to {
    animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
  }

  from {
    opacity: 0;
    transform: translate3d(3000px, 0, 0) scaleX(3);
  }

  60% {
    opacity: 1;
    transform: translate3d(-25px, 0, 0) scaleX(1);
  }

  75% {
    transform: translate3d(10px, 0, 0) scaleX(0.98);
  }

  90% {
    transform: translate3d(-5px, 0, 0) scaleX(0.995);
  }

  to {
    transform: translate3d(0, 0, 0);
  }
`,eI`
  from,
  60%,
  75%,
  90%,
  to {
    animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
  }

  from {
    opacity: 0;
    transform: translate3d(0, 3000px, 0) scaleY(5);
  }

  60% {
    opacity: 1;
    transform: translate3d(0, -20px, 0) scaleY(0.9);
  }

  75% {
    transform: translate3d(0, 10px, 0) scaleY(0.95);
  }

  90% {
    transform: translate3d(0, -5px, 0) scaleY(0.985);
  }

  to {
    transform: translate3d(0, 0, 0);
  }
`,eI`
  20% {
    transform: scale3d(0.9, 0.9, 0.9);
  }

  50%,
  55% {
    opacity: 1;
    transform: scale3d(1.1, 1.1, 1.1);
  }

  to {
    opacity: 0;
    transform: scale3d(0.3, 0.3, 0.3);
  }
`,eI`
  20% {
    transform: translate3d(0, 10px, 0) scaleY(0.985);
  }

  40%,
  45% {
    opacity: 1;
    transform: translate3d(0, -20px, 0) scaleY(0.9);
  }

  to {
    opacity: 0;
    transform: translate3d(0, 2000px, 0) scaleY(3);
  }
`,eI`
  20% {
    opacity: 1;
    transform: translate3d(20px, 0, 0) scaleX(0.9);
  }

  to {
    opacity: 0;
    transform: translate3d(-2000px, 0, 0) scaleX(2);
  }
`,eI`
  20% {
    opacity: 1;
    transform: translate3d(-20px, 0, 0) scaleX(0.9);
  }

  to {
    opacity: 0;
    transform: translate3d(2000px, 0, 0) scaleX(2);
  }
`,eI`
  20% {
    transform: translate3d(0, -10px, 0) scaleY(0.985);
  }

  40%,
  45% {
    opacity: 1;
    transform: translate3d(0, 20px, 0) scaleY(0.9);
  }

  to {
    opacity: 0;
    transform: translate3d(0, -2000px, 0) scaleY(3);
  }
`,eI`
  from {
    opacity: 1;
  }

  to {
    opacity: 0;
  }
`),to=eI`
  from {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }

  to {
    opacity: 0;
    transform: translate3d(-100%, 100%, 0);
  }
`,ti=eI`
  from {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }

  to {
    opacity: 0;
    transform: translate3d(100%, 100%, 0);
  }
`,tl=eI`
  from {
    opacity: 1;
  }

  to {
    opacity: 0;
    transform: translate3d(0, 100%, 0);
  }
`,tc=eI`
  from {
    opacity: 1;
  }

  to {
    opacity: 0;
    transform: translate3d(0, 2000px, 0);
  }
`,td=eI`
  from {
    opacity: 1;
  }

  to {
    opacity: 0;
    transform: translate3d(-100%, 0, 0);
  }
`,tf=eI`
  from {
    opacity: 1;
  }

  to {
    opacity: 0;
    transform: translate3d(-2000px, 0, 0);
  }
`,tm=eI`
  from {
    opacity: 1;
  }

  to {
    opacity: 0;
    transform: translate3d(100%, 0, 0);
  }
`,tu=eI`
  from {
    opacity: 1;
  }

  to {
    opacity: 0;
    transform: translate3d(2000px, 0, 0);
  }
`,tp=eI`
  from {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }

  to {
    opacity: 0;
    transform: translate3d(-100%, -100%, 0);
  }
`,th=eI`
  from {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }

  to {
    opacity: 0;
    transform: translate3d(100%, -100%, 0);
  }
`,tx=eI`
  from {
    opacity: 1;
  }

  to {
    opacity: 0;
    transform: translate3d(0, -100%, 0);
  }
`,ty=eI`
  from {
    opacity: 1;
  }

  to {
    opacity: 0;
    transform: translate3d(0, -2000px, 0);
  }
`,tg=e=>{let{big:t=!1,direction:r,reverse:a=!1,...n}=e;return eM(tt,{keyframes:(0,s.useMemo)(()=>(function(e,t,r){switch(r){case"bottom-left":return t?to:eJ;case"bottom-right":return t?ti:eZ;case"down":return e?t?tc:e0:t?tl:eK;case"left":return e?t?tf:e3:t?td:e1;case"right":return e?t?tu:e2:t?tm:e5;case"top-left":return t?tp:e4;case"top-right":return t?th:e6;case"up":return e?t?ty:e9:t?tx:e7;default:return t?ts:eQ}})(t,a,r),[t,r,a]),...n})};eI`
  from {
    transform: perspective(400px) scale3d(1, 1, 1) translate3d(0, 0, 0) rotate3d(0, 1, 0, -360deg);
    animation-timing-function: ease-out;
  }

  40% {
    transform: perspective(400px) scale3d(1, 1, 1) translate3d(0, 0, 150px)
      rotate3d(0, 1, 0, -190deg);
    animation-timing-function: ease-out;
  }

  50% {
    transform: perspective(400px) scale3d(1, 1, 1) translate3d(0, 0, 150px)
      rotate3d(0, 1, 0, -170deg);
    animation-timing-function: ease-in;
  }

  80% {
    transform: perspective(400px) scale3d(0.95, 0.95, 0.95) translate3d(0, 0, 0)
      rotate3d(0, 1, 0, 0deg);
    animation-timing-function: ease-in;
  }

  to {
    transform: perspective(400px) scale3d(1, 1, 1) translate3d(0, 0, 0) rotate3d(0, 1, 0, 0deg);
    animation-timing-function: ease-in;
  }
`,eI`
  from {
    transform: perspective(400px) rotate3d(1, 0, 0, 90deg);
    animation-timing-function: ease-in;
    opacity: 0;
  }

  40% {
    transform: perspective(400px) rotate3d(1, 0, 0, -20deg);
    animation-timing-function: ease-in;
  }

  60% {
    transform: perspective(400px) rotate3d(1, 0, 0, 10deg);
    opacity: 1;
  }

  80% {
    transform: perspective(400px) rotate3d(1, 0, 0, -5deg);
  }

  to {
    transform: perspective(400px);
  }
`,eI`
  from {
    transform: perspective(400px) rotate3d(0, 1, 0, 90deg);
    animation-timing-function: ease-in;
    opacity: 0;
  }

  40% {
    transform: perspective(400px) rotate3d(0, 1, 0, -20deg);
    animation-timing-function: ease-in;
  }

  60% {
    transform: perspective(400px) rotate3d(0, 1, 0, 10deg);
    opacity: 1;
  }

  80% {
    transform: perspective(400px) rotate3d(0, 1, 0, -5deg);
  }

  to {
    transform: perspective(400px);
  }
`,eI`
  from {
    transform: perspective(400px);
  }

  30% {
    transform: perspective(400px) rotate3d(1, 0, 0, -20deg);
    opacity: 1;
  }

  to {
    transform: perspective(400px) rotate3d(1, 0, 0, 90deg);
    opacity: 0;
  }
`,eI`
  from {
    transform: perspective(400px);
  }

  30% {
    transform: perspective(400px) rotate3d(0, 1, 0, -15deg);
    opacity: 1;
  }

  to {
    transform: perspective(400px) rotate3d(0, 1, 0, 90deg);
    opacity: 0;
  }
`,eI`
  0% {
    animation-timing-function: ease-in-out;
  }

  20%,
  60% {
    transform: rotate3d(0, 0, 1, 80deg);
    animation-timing-function: ease-in-out;
  }

  40%,
  80% {
    transform: rotate3d(0, 0, 1, 60deg);
    animation-timing-function: ease-in-out;
    opacity: 1;
  }

  to {
    transform: translate3d(0, 700px, 0);
    opacity: 0;
  }
`,eI`
  from {
    opacity: 0;
    transform: scale(0.1) rotate(30deg);
    transform-origin: center bottom;
  }

  50% {
    transform: rotate(-10deg);
  }

  70% {
    transform: rotate(3deg);
  }

  to {
    opacity: 1;
    transform: scale(1);
  }
`,eI`
  from {
    opacity: 0;
    transform: translate3d(-100%, 0, 0) rotate3d(0, 0, 1, -120deg);
  }

  to {
    opacity: 1;
    transform: translate3d(0, 0, 0);
  }
`,eI`
  from {
    opacity: 1;
  }

  to {
    opacity: 0;
    transform: translate3d(100%, 0, 0) rotate3d(0, 0, 1, 120deg);
  }
`,eI`
  from {
    transform: rotate3d(0, 0, 1, -200deg);
    opacity: 0;
  }

  to {
    transform: translate3d(0, 0, 0);
    opacity: 1;
  }
`,eI`
  from {
    transform: rotate3d(0, 0, 1, -45deg);
    opacity: 0;
  }

  to {
    transform: translate3d(0, 0, 0);
    opacity: 1;
  }
`,eI`
  from {
    transform: rotate3d(0, 0, 1, 45deg);
    opacity: 0;
  }

  to {
    transform: translate3d(0, 0, 0);
    opacity: 1;
  }
`,eI`
  from {
    transform: rotate3d(0, 0, 1, 45deg);
    opacity: 0;
  }

  to {
    transform: translate3d(0, 0, 0);
    opacity: 1;
  }
`,eI`
  from {
    transform: rotate3d(0, 0, 1, -90deg);
    opacity: 0;
  }

  to {
    transform: translate3d(0, 0, 0);
    opacity: 1;
  }
`,eI`
  from {
    opacity: 1;
  }

  to {
    transform: rotate3d(0, 0, 1, 200deg);
    opacity: 0;
  }
`,eI`
  from {
    opacity: 1;
  }

  to {
    transform: rotate3d(0, 0, 1, 45deg);
    opacity: 0;
  }
`,eI`
  from {
    opacity: 1;
  }

  to {
    transform: rotate3d(0, 0, 1, -45deg);
    opacity: 0;
  }
`,eI`
  from {
    opacity: 1;
  }

  to {
    transform: rotate3d(0, 0, 1, -45deg);
    opacity: 0;
  }
`,eI`
  from {
    opacity: 1;
  }

  to {
    transform: rotate3d(0, 0, 1, 90deg);
    opacity: 0;
  }
`,eI`
  from {
    transform: translate3d(0, -100%, 0);
    visibility: visible;
  }

  to {
    transform: translate3d(0, 0, 0);
  }
`,eI`
  from {
    transform: translate3d(-100%, 0, 0);
    visibility: visible;
  }

  to {
    transform: translate3d(0, 0, 0);
  }
`,eI`
  from {
    transform: translate3d(100%, 0, 0);
    visibility: visible;
  }

  to {
    transform: translate3d(0, 0, 0);
  }
`,eI`
  from {
    transform: translate3d(0, 100%, 0);
    visibility: visible;
  }

  to {
    transform: translate3d(0, 0, 0);
  }
`,eI`
  from {
    transform: translate3d(0, 0, 0);
  }

  to {
    visibility: hidden;
    transform: translate3d(0, 100%, 0);
  }
`,eI`
  from {
    transform: translate3d(0, 0, 0);
  }

  to {
    visibility: hidden;
    transform: translate3d(-100%, 0, 0);
  }
`,eI`
  from {
    transform: translate3d(0, 0, 0);
  }

  to {
    visibility: hidden;
    transform: translate3d(100%, 0, 0);
  }
`,eI`
  from {
    transform: translate3d(0, 0, 0);
  }

  to {
    visibility: hidden;
    transform: translate3d(0, -100%, 0);
  }
`,eI`
  from {
    opacity: 0;
    transform: scale3d(0.3, 0.3, 0.3);
  }

  50% {
    opacity: 1;
  }
`,eI`
  from {
    opacity: 0;
    transform: scale3d(0.1, 0.1, 0.1) translate3d(0, -1000px, 0);
    animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
  }

  60% {
    opacity: 1;
    transform: scale3d(0.475, 0.475, 0.475) translate3d(0, 60px, 0);
    animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
  }
`,eI`
  from {
    opacity: 0;
    transform: scale3d(0.1, 0.1, 0.1) translate3d(-1000px, 0, 0);
    animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
  }

  60% {
    opacity: 1;
    transform: scale3d(0.475, 0.475, 0.475) translate3d(10px, 0, 0);
    animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
  }
`,eI`
  from {
    opacity: 0;
    transform: scale3d(0.1, 0.1, 0.1) translate3d(1000px, 0, 0);
    animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
  }

  60% {
    opacity: 1;
    transform: scale3d(0.475, 0.475, 0.475) translate3d(-10px, 0, 0);
    animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
  }
`,eI`
  from {
    opacity: 0;
    transform: scale3d(0.1, 0.1, 0.1) translate3d(0, 1000px, 0);
    animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
  }

  60% {
    opacity: 1;
    transform: scale3d(0.475, 0.475, 0.475) translate3d(0, -60px, 0);
    animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
  }
`,eI`
  from {
    opacity: 1;
  }

  50% {
    opacity: 0;
    transform: scale3d(0.3, 0.3, 0.3);
  }

  to {
    opacity: 0;
  }
`,eI`
  40% {
    opacity: 1;
    transform: scale3d(0.475, 0.475, 0.475) translate3d(0, -60px, 0);
    animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
  }

  to {
    opacity: 0;
    transform: scale3d(0.1, 0.1, 0.1) translate3d(0, 2000px, 0);
    animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
  }
`,eI`
  40% {
    opacity: 1;
    transform: scale3d(0.475, 0.475, 0.475) translate3d(42px, 0, 0);
  }

  to {
    opacity: 0;
    transform: scale(0.1) translate3d(-2000px, 0, 0);
  }
`,eI`
  40% {
    opacity: 1;
    transform: scale3d(0.475, 0.475, 0.475) translate3d(-42px, 0, 0);
  }

  to {
    opacity: 0;
    transform: scale(0.1) translate3d(2000px, 0, 0);
  }
`,eI`
  40% {
    opacity: 1;
    transform: scale3d(0.475, 0.475, 0.475) translate3d(0, 60px, 0);
    animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
  }

  to {
    opacity: 0;
    transform: scale3d(0.1, 0.1, 0.1) translate3d(0, -2000px, 0);
    animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
  }
`;let tb=()=>(0,n.jsxs)("div",{id:"about",className:"min-h-screen border-t border-white/30 text-white flex flex-col items-center justify-center px-6 py-12 w-full",children:[(0,n.jsx)(o.P.h1,{className:"text-4xl md:text-5xl font-bold text-center bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500",initial:{opacity:0,y:-20},animate:{opacity:1,y:0},transition:{duration:1},children:"ShieldBot – Advanced Security Testing"}),(0,n.jsx)("p",{className:"mt-2 text-sm md:text-lg text-gray-400 text-center max-w-2xl",children:"Simulate real-world cyber threats and fortify your defenses against DDoS attacks."}),(0,n.jsxs)("div",{className:"mt-10 grid grid-cols-1 sm:grid-cols-2 gap-6 max-w-5xl w-full px-4",children:[(0,n.jsx)(tg,{direction:"up",triggerOnce:!0,children:(0,n.jsxs)("div",{className:"bg-gray-800/70 p-6 rounded-xl shadow-lg flex flex-col items-center text-center space-y-3 transform hover:scale-105 transition duration-300",children:[(0,n.jsx)(l,{size:40,className:"text-red-500"}),(0,n.jsx)("h3",{className:"text-lg md:text-xl font-semibold",children:"DDoS Attack Simulation"}),(0,n.jsx)("p",{className:"text-sm md:text-base text-gray-400",children:"Run controlled attack scenarios to test website resilience."})]})}),(0,n.jsx)(tg,{direction:"up",delay:100,triggerOnce:!0,children:(0,n.jsxs)("div",{className:"bg-gray-800/70 p-6 rounded-xl shadow-lg flex flex-col items-center text-center space-y-3 transform hover:scale-105 transition duration-300",children:[(0,n.jsx)(c,{size:40,className:"text-blue-500"}),(0,n.jsx)("h3",{className:"text-lg md:text-xl font-semibold",children:"Global Load Testing"}),(0,n.jsx)("p",{className:"text-sm md:text-base text-gray-400",children:"Evaluate performance under high-traffic conditions worldwide."})]})}),(0,n.jsx)(tg,{direction:"up",delay:200,triggerOnce:!0,children:(0,n.jsxs)("div",{className:"bg-gray-800/70 p-6 rounded-xl shadow-lg flex flex-col items-center text-center space-y-3 transform hover:scale-105 transition duration-300",children:[(0,n.jsx)(d,{size:40,className:"text-green-500"}),(0,n.jsx)("h3",{className:"text-lg md:text-xl font-semibold",children:"Live Security Analytics"}),(0,n.jsx)("p",{className:"text-sm md:text-base text-gray-400",children:"Monitor security responses and adjust defenses in real-time."})]})}),(0,n.jsx)(tg,{direction:"up",delay:300,triggerOnce:!0,children:(0,n.jsxs)("div",{className:"bg-gray-800/70 p-6 rounded-xl shadow-lg flex flex-col items-center text-center space-y-3 transform hover:scale-105 transition duration-300",children:[(0,n.jsx)(f,{size:40,className:"text-yellow-500"}),(0,n.jsx)("h3",{className:"text-lg md:text-xl font-semibold",children:"Threat Prevention Reports"}),(0,n.jsx)("p",{className:"text-sm md:text-base text-gray-400",children:"Receive actionable insights to enhance security infrastructure."})]})})]})]})},95625:(e,t,r)=>{"use strict";r.d(t,{default:()=>u});var a=r(45512),n=r(58009),s=r(4725);let o=n.forwardRef(function({title:e,titleId:t,...r},a){return n.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",fill:"currentColor","aria-hidden":"true","data-slot":"icon",ref:a,"aria-labelledby":t},r),e?n.createElement("title",{id:t},e):null,n.createElement("path",{fillRule:"evenodd",d:"M9 4.5a.75.75 0 0 1 .721.544l.813 2.846a3.75 3.75 0 0 0 2.576 2.576l2.846.813a.75.75 0 0 1 0 1.442l-2.846.813a3.75 3.75 0 0 0-2.576 2.576l-.813 2.846a.75.75 0 0 1-1.442 0l-.813-2.846a3.75 3.75 0 0 0-2.576-2.576l-2.846-.813a.75.75 0 0 1 0-1.442l2.846-.813A3.75 3.75 0 0 0 7.466 7.89l.813-2.846A.75.75 0 0 1 9 4.5ZM18 1.5a.75.75 0 0 1 .728.568l.258 1.036c.236.94.97 1.674 1.91 1.91l1.036.258a.75.75 0 0 1 0 1.456l-1.036.258c-.94.236-1.674.97-1.91 1.91l-.258 1.036a.75.75 0 0 1-1.456 0l-.258-1.036a2.625 2.625 0 0 0-1.91-1.91l-1.036-.258a.75.75 0 0 1 0-1.456l1.036-.258a2.625 2.625 0 0 0 1.91-1.91l.258-1.036A.75.75 0 0 1 18 1.5ZM16.5 15a.75.75 0 0 1 .712.513l.394 1.183c.15.447.5.799.948.948l1.183.395a.75.75 0 0 1 0 1.422l-1.183.395c-.447.15-.799.5-.948.948l-.395 1.183a.75.75 0 0 1-1.422 0l-.395-1.183a1.5 1.5 0 0 0-.948-.948l-1.183-.395a.75.75 0 0 1 0-1.422l1.183-.395c.447-.15.799-.5.948-.948l.395-1.183A.75.75 0 0 1 16.5 15Z",clipRule:"evenodd"}))}),i=({children:e,padding:t=100,disabled:r=!1,magnetStrength:s=2,activeTransition:o="transform 0.3s ease-out",inactiveTransition:i="transform 0.5s ease-in-out",wrapperClassName:l="",innerClassName:c="",...d})=>{let[f,m]=(0,n.useState)(!1),[u,p]=(0,n.useState)({x:0,y:0}),h=(0,n.useRef)(null);return(0,n.useEffect)(()=>{if(r){p({x:0,y:0});return}let e=e=>{if(!h.current)return;let{left:r,top:a,width:n,height:o}=h.current.getBoundingClientRect(),i=r+n/2,l=a+o/2,c=Math.abs(i-e.clientX),d=Math.abs(l-e.clientY);c<n/2+t&&d<o/2+t?(m(!0),p({x:(e.clientX-i)/s,y:(e.clientY-l)/s})):(m(!1),p({x:0,y:0}))};return window.addEventListener("mousemove",e),()=>{window.removeEventListener("mousemove",e)}},[t,r,s]),(0,a.jsx)("div",{ref:h,className:l,style:{position:"relative",display:"inline-block"},...d,children:(0,a.jsx)("div",{className:c,style:{transform:`translate3d(${u.x}px, ${u.y}px, 0)`,transition:f?o:i,willChange:"transform"},children:e})})};var l=r(6648);function c(...e){return e.filter(Boolean).join(" ")}let d=(0,n.forwardRef)((e,t)=>{let{texts:r,transition:o={type:"spring",damping:25,stiffness:300},initial:i={y:"100%",opacity:0},animate:d={y:0,opacity:1},exit:f={y:"-120%",opacity:0},animatePresenceMode:m="wait",animatePresenceInitial:u=!1,rotationInterval:p=2e3,staggerDuration:h=0,staggerFrom:x="first",loop:y=!0,auto:g=!0,splitBy:b="characters",onNext:v,mainClassName:w,splitLevelClassName:j,elementLevelClassName:k,...N}=e,[S,C]=(0,n.useState)(0),P=e=>"undefined"!=typeof Intl&&Intl.Segmenter?Array.from(new Intl.Segmenter("en",{granularity:"grapheme"}).segment(e),e=>e.segment):Array.from(e),A=(0,n.useMemo)(()=>{let e=r[S];if("characters"===b){let t=e.split(" ");return t.map((e,r)=>({characters:P(e),needsSpace:r!==t.length-1}))}return"words"===b?e.split(" ").map((e,t,r)=>({characters:[e],needsSpace:t!==r.length-1})):"lines"===b?e.split("\n").map((e,t,r)=>({characters:[e],needsSpace:t!==r.length-1})):e.split(b).map((e,t,r)=>({characters:[e],needsSpace:t!==r.length-1}))},[r,S,b]),O=(0,n.useCallback)((e,t)=>"first"===x?e*h:"last"===x?(t-1-e)*h:"center"===x?Math.abs(Math.floor(t/2)-e)*h:"random"===x?Math.abs(Math.floor(Math.random()*t)-e)*h:Math.abs(x-e)*h,[x,h]),E=(0,n.useCallback)(e=>{C(e),v&&v(e)},[v]),$=(0,n.useCallback)(()=>{let e=S===r.length-1?y?0:S:S+1;e!==S&&E(e)},[S,r.length,y,E]),M=(0,n.useCallback)(()=>{let e=0===S?y?r.length-1:S:S-1;e!==S&&E(e)},[S,r.length,y,E]),z=(0,n.useCallback)(e=>{let t=Math.max(0,Math.min(e,r.length-1));t!==S&&E(t)},[r.length,S,E]),_=(0,n.useCallback)(()=>{0!==S&&E(0)},[S,E]);return(0,n.useImperativeHandle)(t,()=>({next:$,previous:M,jumpTo:z,reset:_}),[$,M,z,_]),(0,n.useEffect)(()=>{if(!g)return;let e=setInterval($,p);return()=>clearInterval(e)},[$,p,g]),(0,a.jsxs)(s.P.span,{className:c("flex flex-wrap whitespace-pre-wrap relative",w),...N,layout:!0,transition:o,children:[(0,a.jsx)("span",{className:"sr-only",children:r[S]}),(0,a.jsx)(l.N,{mode:m,initial:u,children:(0,a.jsx)(s.P.div,{className:c("lines"===b?"flex flex-col w-full":"flex flex-wrap whitespace-pre-wrap relative"),layout:!0,"aria-hidden":"true",children:A.map((e,t,r)=>{let n=r.slice(0,t).reduce((e,t)=>e+t.characters.length,0);return(0,a.jsxs)("span",{className:c("inline-flex",j),children:[e.characters.map((e,t)=>(0,a.jsx)(s.P.span,{initial:i,animate:d,exit:f,transition:{...o,delay:O(n+t,r.reduce((e,t)=>e+t.characters.length,0))},className:c("inline-block",k),children:e},t)),e.needsSpace&&(0,a.jsx)("span",{className:"whitespace-pre",children:" "})]},t)})},S)})]})});d.displayName="RotatingText";var f=r(28531),m=r.n(f);let u=()=>{let[e,t]=(0,n.useState)({x:0,y:0});return(0,a.jsxs)("div",{id:"home",className:"relative h-screen w-full flex justify-center items-center text-white bg-cover bg-center px-6 sm:px-12 lg:px-20 overflow-hidden",style:{backgroundImage:"url('/bg.webp')"},onMouseMove:e=>{t({x:e.clientX/window.innerWidth*20-10,y:e.clientY/window.innerHeight*20-10})},children:[(0,a.jsx)(s.P.div,{className:"absolute inset-0 bg-black/50 backdrop-blur-sm",animate:{x:e.x,y:e.y},transition:{ease:"easeOut",duration:.5}}),(0,a.jsxs)(s.P.div,{initial:{opacity:0,y:50},animate:{opacity:1,y:0},transition:{duration:1,ease:"easeOut"},className:"relative flex flex-col items-center text-center gap-6 sm:gap-8 md:gap-10 px-4",children:[(0,a.jsxs)("div",{children:[(0,a.jsxs)("h1",{className:"font-extrabold text-5xl sm:text-5xl md:text-6xl lg:text-7xl xl:text-8xl md:flex-row flex-col flex gap-6 lg:gap-10 tracking-tight leading-tight text-white drop-shadow-xl",children:["Secure Your"," ",(0,a.jsx)("span",{className:"text-green-400 text-5xl sm:text-6xl md:text-7xl",children:(0,a.jsx)(d,{texts:["Security","Shield","Encryption","Privacy!"],mainClassName:"px-2 sm:px-3 md:px-4 bg-cyan-300 text-black overflow-hidden py-0.5 sm:py-1 md:py-2 justify-center rounded-lg",staggerFrom:"last",initial:{y:"100%"},animate:{y:0},exit:{y:"-120%"},staggerDuration:.025,splitLevelClassName:"overflow-hidden pb-0.5 sm:pb-1 md:pb-1",transition:{type:"spring",damping:30,stiffness:400},rotationInterval:2e3})})]}),(0,a.jsxs)("h1",{className:"font-semibold text-xl sm:text-2xl md:text-3xl lg:text-4xl text-green-400 mt-3 flex items-center justify-center",children:["Before Hackers Do!"," ",(0,a.jsx)(o,{className:"w-6 h-6 sm:w-8 sm:h-8 ml-2 text-yellow-300"})]})]}),(0,a.jsx)(m(),{href:"/login",children:(0,a.jsx)(i,{padding:200,disabled:!1,magnetStrength:10,children:(0,a.jsx)(s.P.button,{whileHover:{scale:1.1,boxShadow:"0px 0px 15px rgba(34, 197, 94, 0.8)"},transition:{type:"spring",stiffness:200},className:"text-lg sm:text-base md:text-lg lg:text-xl font-semibold text-black bg-green-500 hover:bg-green-400 duration-300 px-5 sm:px-6 md:px-8 py-2 sm:py-3 md:py-4 rounded-lg shadow-lg",children:"Test Now \uD83D\uDE80"})})})]})]})}},37892:(e,t,r)=>{"use strict";r.d(t,{default:()=>d});var a=r(45512),n=r(79334);r(5698);let s=({href:e,children:t,delay:r=700,className:s})=>{let o=(0,n.useRouter)();return(0,a.jsx)("a",{href:e,onClick:t=>{t.preventDefault(),setTimeout(()=>{o.push(e)},r)},className:s,children:t})};var o=r(28531),i=r.n(o),l=r(58009),c=r(42534);let d=()=>{let[e,t]=(0,l.useState)(!1),[r,n]=(0,l.useState)(!1),[o,d]=(0,l.useState)("");return(0,l.useEffect)(()=>{let e=localStorage.getItem("authToken"),t=localStorage.getItem("profilePic");e&&(n(!0),t&&d(t))},[]),(0,a.jsxs)("div",{className:"flex w-full justify-center",children:[(0,a.jsx)("nav",{className:"fixed border border-white/10 top-5 w-[90%] md:w-1/2 py-3 mx-auto bg-white/10 backdrop-blur-md text-white rounded-xl z-40",children:(0,a.jsxs)("div",{className:"flex justify-between items-center py-4 px-6",children:[(0,a.jsx)(i(),{href:"/",children:(0,a.jsxs)("h1",{className:"text-2xl xl:text-4xl font-bold cursor-pointer",children:["Shield",(0,a.jsx)("span",{className:"text-red-500",children:"Bot"})]})}),(0,a.jsx)("button",{className:"xl:hidden text-white text-3xl",onClick:()=>t(!e),children:e?(0,a.jsx)(c.yGN,{}):(0,a.jsx)(c.ND1,{})}),(0,a.jsxs)("div",{className:"hidden xl:flex gap-5 text-xl font-medium text-gray-400",children:[(0,a.jsx)(i(),{href:"#home",children:(0,a.jsx)("h1",{className:"hover:bg-gray-600/20 px-5 py-2 rounded-md hover:text-white duration-200",children:"Home"})}),(0,a.jsx)(i(),{href:"#about",children:(0,a.jsx)("h1",{className:"hover:bg-gray-600/20 px-5 py-2 rounded-md hover:text-white duration-200",children:"About Us"})}),(0,a.jsx)(i(),{href:"#faq",children:(0,a.jsx)("h1",{className:"hover:bg-gray-600/20 px-5 py-2 rounded-md hover:text-white duration-200",children:"FAQ"})})]}),(0,a.jsx)("div",{className:"hidden xl:flex items-center gap-5",children:r?(0,a.jsx)(i(),{href:"/profile",children:o?(0,a.jsx)("img",{src:o,alt:"Profile",className:"w-10 h-10 rounded-full border-2 border-blue-400 shadow-lg cursor-pointer"}):(0,a.jsx)(c.JXP,{className:"text-3xl cursor-pointer hover:text-blue-400"})}):(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)(s,{delay:500,href:"/login",children:(0,a.jsx)("button",{className:"text-gray-400 hover:text-blue-300 duration-200",children:"Log In"})}),(0,a.jsx)(s,{delay:500,href:"/signup",children:(0,a.jsx)("button",{className:"text-md bg-blue-700 hover:bg-blue-600 duration-300 px-6 py-3 rounded-xl",children:"Sign Up"})})]})})]})}),(0,a.jsxs)("div",{className:`z-40 fixed inset-0 bg-[#1f252c] text-white flex flex-col items-center justify-center gap-8 text-2xl font-medium transform transition-transform duration-500 ${e?"translate-x-0":"translate-x-full"} xl:hidden`,children:[(0,a.jsx)(i(),{href:"#home",onClick:()=>t(!1),children:"Home"}),(0,a.jsx)(i(),{href:"#about",onClick:()=>t(!1),children:"About Us"}),(0,a.jsx)(i(),{href:"#faq",onClick:()=>t(!1),children:"FAQ"}),r?(0,a.jsx)(i(),{href:"/profile",onClick:()=>t(!1),children:o?(0,a.jsx)("img",{src:o,alt:"Profile",className:"w-16 h-16 rounded-full border-4 border-blue-400 shadow-lg"}):(0,a.jsx)(c.JXP,{className:"text-4xl cursor-pointer hover:text-blue-400"})}):(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)(i(),{href:"/login",children:(0,a.jsx)("button",{className:"text-gray-400 hover:text-blue-300 duration-200",onClick:()=>t(!1),children:"Log In"})}),(0,a.jsx)(i(),{href:"/signup",children:(0,a.jsx)("button",{className:"text-xl bg-blue-700 hover:bg-blue-600 duration-300 px-6 py-3 rounded-xl",onClick:()=>t(!1),children:"Sign Up"})})]})]})]})}},54087:(e,t,r)=>{"use strict";r.d(t,{default:()=>o});var a=r(45512),n=r(58009),s=r(42534);let o=()=>{let[e,t]=(0,n.useState)(""),[r,o]=(0,n.useState)(null);(0,n.useEffect)(()=>{let e=()=>{t(window.location.hash)};return e(),window.addEventListener("hashchange",e),()=>{window.removeEventListener("hashchange",e)}},[]);let i=e=>{t(e),window.location.hash=e};return(0,a.jsxs)("div",{className:"z-40 fixed top-1/2 left-5 transform -translate-y-1/2 bg-white/10 backdrop-blur-lg shadow-lg border border-white/20   text-white xl:flex flex-col items-center gap-10 py-6 px-4 rounded-3xl hidden transition-all duration-500",children:[(0,a.jsxs)("button",{onClick:()=>i(""),onMouseEnter:()=>o("Home"),onMouseLeave:()=>o(null),className:`relative px-6 py-4 rounded-full transition duration-300 flex items-center justify-center shadow-md
                    ${""===e?"bg-blue-600 scale-110":"hover:bg-gray-700"}`,children:[(0,a.jsx)(s.V5Y,{className:"text-2xl"}),"Home"===r&&(0,a.jsx)("span",{className:"absolute left-16 bg-black text-white text-xs px-3 py-1 rounded-lg shadow-md transition-opacity duration-200",children:"Home"})]}),(0,a.jsxs)("button",{onClick:()=>i("#team"),onMouseEnter:()=>o("Team"),onMouseLeave:()=>o(null),className:`relative px-6 py-4 rounded-full transition duration-300 flex items-center justify-center shadow-md
                    ${"#team"===e?"bg-blue-600 scale-110":"hover:bg-gray-700"}`,children:[(0,a.jsx)(s.cfS,{className:"text-2xl"}),"Team"===r&&(0,a.jsx)("span",{className:"absolute left-16 bg-black text-white text-xs px-3 py-1 rounded-lg shadow-md transition-opacity duration-200",children:"Team"})]}),(0,a.jsxs)("button",{onClick:()=>{window.confirm("Are you sure you want to log out?")&&(localStorage.clear(),window.location.reload())},onMouseEnter:()=>o("Logout"),onMouseLeave:()=>o(null),className:"relative px-6 py-4 rounded-full hover:bg-red-700 transition duration-300 flex items-center justify-center shadow-md",children:[(0,a.jsx)(s.QeK,{className:"text-2xl"}),"Logout"===r&&(0,a.jsx)("span",{className:"absolute left-16 bg-black text-white text-xs px-3 py-1 rounded-lg shadow-md transition-opacity duration-200",children:"Logout"})]})]})}},29008:(e,t,r)=>{"use strict";r.d(t,{default:()=>d});var a=r(45512),n=r(58009),s=r(4725),o=r(52414);let i=()=>{let[e,t]=(0,n.useState)([]);return(0,n.useEffect)(()=>{t(Array(10).fill(0).map((e,t)=>({left:100*Math.random()+"vw",id:t,top:100*Math.random()+"vh",duration:3*Math.random()+2})))},[]),(0,a.jsx)(a.Fragment,{children:e.map(e=>(0,a.jsx)(s.P.div,{className:"absolute w-1 h-1 bg-white rounded-full shadow-lg",style:{left:e.left,top:e.top},animate:{x:[0,-200],y:[0,200],opacity:[1,0]},transition:{duration:e.duration,repeat:1/0,ease:"linear"}},e.id))})},l=[{name:"Shashank Kumar",role:"DevOps",image:"https://avatars.githubusercontent.com/u/109029541?v=4",insta:"https://instagram.com/",github:"https://github.com/shashank77665",linkedin:"https://linkedin.com/in/"},{name:"Paras Saini",role:"Backend Engineer",image:"https://avatars.githubusercontent.com/u/126291053?v=4",insta:"https://instagram.com/",github:"https://github.com/Paras-17",linkedin:"https://linkedin.com/in/"},{name:"Dashrath Nandan",role:"UI/UX Designer",image:"/member4.jpg",insta:"https://instagram.com/",github:"https://github.com/Dashrath2613",linkedin:"https://linkedin.com/in/"},{name:"Yash Chauhan",role:"Documentation",image:"https://www.pngplay.com/wp-content/uploads/12/User-Avatar-Profile-PNG-Free-File-Download.png",insta:"#",github:"#",linkedin:"#"},{name:"Hritika Singh",role:"Documentation",image:"https://cdn-icons-png.flaticon.com/512/2922/2922725.png",insta:"#",github:"#",linkedin:"#"}],c=({member:e})=>{let[t,r]=(0,n.useState)({x:0,y:0});return(0,a.jsxs)(s.P.div,{className:"bg-white/10 p-6 rounded-2xl shadow-lg text-center flex flex-col items-center w-72 transition-all",style:{transform:`perspective(500px) rotateX(${t.y}deg) rotateY(${t.x}deg)`,transition:"transform 0.2s ease-out"},onMouseMove:e=>{let{clientX:t,clientY:a,currentTarget:n}=e,{left:s,top:o,width:i,height:l}=n.getBoundingClientRect();r({x:(t-s-i/2)/25,y:-(a-o-l/2)/25})},onMouseLeave:()=>{r({x:0,y:0})},children:[(0,a.jsx)("div",{className:"w-72 h-72 p-4 overflow-hidden rounded-lg",children:(0,a.jsx)("img",{src:e.image,alt:e.name,className:"w-full border border-white h-full rounded-lg object-cover"})}),(0,a.jsx)("h2",{className:"text-2xl font-semibold text-white mt-4",children:e.name}),(0,a.jsx)("p",{className:"text-md text-gray-300 mb-4",children:e.role}),(0,a.jsxs)("div",{className:"flex gap-4 text-xl",children:[(0,a.jsx)("a",{href:e.insta,target:"_blank",rel:"noopener noreferrer",className:"text-pink-400 hover:text-pink-300 transition",children:(0,a.jsx)(o.ao$,{})}),(0,a.jsx)("a",{href:e.github,target:"_blank",rel:"noopener noreferrer",className:"text-gray-400 hover:text-gray-200 transition",children:(0,a.jsx)(o.hL4,{})}),(0,a.jsx)("a",{href:e.linkedin,target:"_blank",rel:"noopener noreferrer",className:"text-blue-400 hover:text-blue-300 transition",children:(0,a.jsx)(o.QEs,{})})]})]})},d=()=>(0,a.jsxs)("div",{id:"team",className:"relative min-h-screen flex flex-col items-center justify-center text-white px-6 py-12 overflow-hidden",children:[(0,a.jsx)(i,{}),(0,a.jsx)("h1",{className:"text-5xl font-bold text-white mb-20",children:"Our Team \uD83D\uDE0E"}),(0,a.jsx)("div",{className:"flex flex-wrap justify-center gap-10",children:l.map((e,t)=>(0,a.jsx)(c,{member:e},t))})]})},5698:(e,t,r)=>{"use strict";r.r(t),r.d(t,{LoadingProvider:()=>c,useLoading:()=>d});var a=r(45512),n=r(58009),s=r(79334),o=r(6648),i=r(4725);let l=(0,n.createContext)(),c=({children:e})=>{let[t,r]=(0,n.useState)(!1),i=(0,s.usePathname)(),c=()=>{r(!0),setTimeout(()=>{r(!1)},1200)};return(0,n.useEffect)(()=>{c()},[i]),(0,n.useEffect)(()=>{let e=()=>{c()};return window.addEventListener("popstate",e),()=>{window.removeEventListener("popstate",e)}},[]),(0,a.jsxs)(l.Provider,{value:{loading:t,setLoading:r},children:[(0,a.jsx)(o.N,{mode:"wait",children:t&&(0,a.jsx)(f,{})}),e]})},d=()=>(0,n.useContext)(l),f=()=>(0,a.jsx)(i.P.div,{className:"fixed top-0 left-0 w-full h-screen flex items-center justify-center z-50",initial:{x:"-100%"},animate:{x:"0%"},exit:{x:"100%"},transition:{duration:.8,ease:"easeInOut"},style:{backgroundColor:"#121212",zIndex:1e3},children:(0,a.jsx)(i.P.div,{className:"text-white text-4xl font-bold tracking-widest",initial:{opacity:0,scale:.8},animate:{opacity:1,scale:1},exit:{opacity:0,scale:.8},children:"LOADING..."})})},62804:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>s,metadata:()=>n});var a=r(62740);r(61135),r(39454);let n={title:"ShieldBot- Think Like an Attacker",description:"ShieldBot simulates real-world DDoS attacks to test your website's resilience and identify vulnerabilities. Stay ahead of cyber threats by stress-testing your security before hackers do! \uD83D\uDE80\uD83D\uDEE1️"};function s({children:e}){return(0,a.jsxs)("html",{lang:"en",children:[(0,a.jsxs)("head",{children:[(0,a.jsx)("link",{rel:"preconnect",href:"https://fonts.googleapis.com"}),(0,a.jsx)("link",{rel:"preconnect",href:"https://fonts.gstatic.com"}),(0,a.jsx)("link",{href:"https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,200..800&display=swap",rel:"stylesheet"})]}),(0,a.jsx)("body",{children:e})]})}},24134:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>N});var a=r(62740),n=r(99423),s=r(72322),o=r(76301),i={color:void 0,size:void 0,className:void 0,style:void 0,attr:void 0},l=o.createContext&&o.createContext(i),c=["attr","size","title"];function d(){return(d=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var a in r)Object.prototype.hasOwnProperty.call(r,a)&&(e[a]=r[a])}return e}).apply(this,arguments)}function f(e,t){var r=Object.keys(e);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);t&&(a=a.filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})),r.push.apply(r,a)}return r}function m(e){for(var t=1;t<arguments.length;t++){var r=null!=arguments[t]?arguments[t]:{};t%2?f(Object(r),!0).forEach(function(t){var a,n;a=t,n=r[t],(a=function(e){var t=function(e,t){if("object"!=typeof e||!e)return e;var r=e[Symbol.toPrimitive];if(void 0!==r){var a=r.call(e,t||"default");if("object"!=typeof a)return a;throw TypeError("@@toPrimitive must return a primitive value.")}return("string"===t?String:Number)(e)}(e,"string");return"symbol"==typeof t?t:t+""}(a))in e?Object.defineProperty(e,a,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[a]=n}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(r)):f(Object(r)).forEach(function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(r,t))})}return e}function u(e){return t=>o.createElement(p,d({attr:m({},e.attr)},t),function e(t){return t&&t.map((t,r)=>o.createElement(t.tag,m({key:r},t.attr),e(t.child)))}(e.child))}function p(e){var t=t=>{var r,{attr:a,size:n,title:s}=e,i=function(e,t){if(null==e)return{};var r,a,n=function(e,t){if(null==e)return{};var r={};for(var a in e)if(Object.prototype.hasOwnProperty.call(e,a)){if(t.indexOf(a)>=0)continue;r[a]=e[a]}return r}(e,t);if(Object.getOwnPropertySymbols){var s=Object.getOwnPropertySymbols(e);for(a=0;a<s.length;a++)r=s[a],!(t.indexOf(r)>=0)&&Object.prototype.propertyIsEnumerable.call(e,r)&&(n[r]=e[r])}return n}(e,c),l=n||t.size||"1em";return t.className&&(r=t.className),e.className&&(r=(r?r+" ":"")+e.className),o.createElement("svg",d({stroke:"currentColor",fill:"currentColor",strokeWidth:"0"},t.attr,a,i,{className:r,style:m(m({color:e.color||t.color},t.style),e.style),height:l,width:l,xmlns:"http://www.w3.org/2000/svg"}),s&&o.createElement("title",null,s),e.children)};return void 0!==l?o.createElement(l.Consumer,null,e=>t(e)):t(i)}function h(e){return u({tag:"svg",attr:{viewBox:"0 0 320 512"},child:[{tag:"path",attr:{d:"M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z"},child:[]}]})(e)}function x(e){return u({tag:"svg",attr:{viewBox:"0 0 496 512"},child:[{tag:"path",attr:{d:"M165.9 397.4c0 2-2.3 3.6-5.2 3.6-3.3.3-5.6-1.3-5.6-3.6 0-2 2.3-3.6 5.2-3.6 3-.3 5.6 1.3 5.6 3.6zm-31.1-4.5c-.7 2 1.3 4.3 4.3 4.9 2.6 1 5.6 0 6.2-2s-1.3-4.3-4.3-5.2c-2.6-.7-5.5.3-6.2 2.3zm44.2-1.7c-2.9.7-4.9 2.6-4.6 4.9.3 2 2.9 3.3 5.9 2.6 2.9-.7 4.9-2.6 4.6-4.6-.3-1.9-3-3.2-5.9-2.9zM244.8 8C106.1 8 0 113.3 0 252c0 110.9 69.8 205.8 169.5 239.2 12.8 2.3 17.3-5.6 17.3-12.1 0-6.2-.3-40.4-.3-61.4 0 0-70 15-84.7-29.8 0 0-11.4-29.1-27.8-36.6 0 0-22.9-15.7 1.6-15.4 0 0 24.9 2 38.6 25.8 21.9 38.6 58.6 27.5 72.9 20.9 2.3-16 8.8-27.1 16-33.7-55.9-6.2-112.3-14.3-112.3-110.5 0-27.5 7.6-41.3 23.6-58.9-2.6-6.5-11.1-33.3 2.6-67.9 20.9-6.5 69 27 69 27 20-5.6 41.5-8.5 62.8-8.5s42.8 2.9 62.8 8.5c0 0 48.1-33.6 69-27 13.7 34.7 5.2 61.4 2.6 67.9 16 17.7 25.8 31.5 25.8 58.9 0 96.5-58.9 104.2-114.8 110.5 9.2 7.9 17 22.9 17 46.4 0 33.7-.3 75.4-.3 83.6 0 6.5 4.6 14.4 17.3 12.1C428.2 457.8 496 362.9 496 252 496 113.3 383.5 8 244.8 8zM97.2 352.9c-1.3 1-1 3.3.7 5.2 1.6 1.6 3.9 2.3 5.2 1 1.3-1 1-3.3-.7-5.2-1.6-1.6-3.9-2.3-5.2-1zm-10.8-8.1c-.7 1.3.3 2.9 2.3 3.9 1.6 1 3.6.7 4.3-.7.7-1.3-.3-2.9-2.3-3.9-2-.6-3.6-.3-4.3.7zm32.4 35.6c-1.6 1.3-1 4.3 1.3 6.2 2.3 2.3 5.2 2.6 6.5 1 1.3-1.3.7-4.3-1.3-6.2-2.2-2.3-5.2-2.6-6.5-1zm-11.4-14.7c-1.6 1-1.6 3.6 0 5.9 1.6 2.3 4.3 3.3 5.6 2.3 1.6-1.3 1.6-3.9 0-6.2-1.4-2.3-4-3.3-5.6-2z"},child:[]}]})(e)}function y(e){return u({tag:"svg",attr:{viewBox:"0 0 448 512"},child:[{tag:"path",attr:{d:"M100.28 448H7.4V148.9h92.88zM53.79 108.1C24.09 108.1 0 83.5 0 53.8a53.79 53.79 0 0 1 107.58 0c0 29.7-24.1 54.3-53.79 54.3zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.29-79.2-48.29 0-55.69 37.7-55.69 76.7V448h-92.78V148.9h89.08v40.8h1.3c12.4-23.5 42.69-48.3 87.88-48.3 94 0 111.28 61.9 111.28 142.3V448z"},child:[]}]})(e)}function g(e){return u({tag:"svg",attr:{viewBox:"0 0 512 512"},child:[{tag:"path",attr:{d:"M459.37 151.716c.325 4.548.325 9.097.325 13.645 0 138.72-105.583 298.558-298.558 298.558-59.452 0-114.68-17.219-161.137-47.106 8.447.974 16.568 1.299 25.34 1.299 49.055 0 94.213-16.568 130.274-44.832-46.132-.975-84.792-31.188-98.112-72.772 6.498.974 12.995 1.624 19.818 1.624 9.421 0 18.843-1.3 27.614-3.573-48.081-9.747-84.143-51.98-84.143-102.985v-1.299c13.969 7.797 30.214 12.67 47.431 13.319-28.264-18.843-46.781-51.005-46.781-87.391 0-19.492 5.197-37.36 14.294-52.954 51.655 63.675 129.3 105.258 216.365 109.807-1.624-7.797-2.599-15.918-2.599-24.04 0-57.828 46.782-104.934 104.934-104.934 30.213 0 57.502 12.67 76.67 33.137 23.715-4.548 46.456-13.32 66.599-25.34-7.798 24.366-24.366 44.833-46.132 57.827 21.117-2.273 41.584-8.122 60.426-16.243-14.292 20.791-32.161 39.308-52.628 54.253z"},child:[]}]})(e)}let b=()=>(0,a.jsxs)("footer",{className:"bg-gray-900 text-white py-12 px-6 text-center flex flex-col md:flex-row items-center justify-between shadow-lg border-t border-gray-700 w-full",children:[(0,a.jsxs)("div",{className:"flex flex-col items-center md:items-start text-center md:text-left max-w-md",children:[(0,a.jsx)("h3",{className:"text-3xl font-extrabold text-blue-400 tracking-wide",children:"ShieldBot"}),(0,a.jsx)("p",{className:"text-lg text-gray-300 mt-3 leading-relaxed px-4 md:px-0",children:"Test your website's resilience with real-world DDoS simulations and fortify your defenses."})]}),(0,a.jsxs)("div",{className:"flex space-x-4 mt-6 md:mt-0",children:[(0,a.jsx)("a",{href:"#",className:"bg-blue-600 p-3 rounded-full text-white hover:bg-blue-500 transition-transform transform hover:scale-110",children:(0,a.jsx)(h,{size:20})}),(0,a.jsx)("a",{href:"#",className:"bg-blue-400 p-3 rounded-full text-white hover:bg-blue-300 transition-transform transform hover:scale-110",children:(0,a.jsx)(g,{size:20})}),(0,a.jsx)("a",{href:"#",className:"bg-blue-700 p-3 rounded-full text-white hover:bg-blue-600 transition-transform transform hover:scale-110",children:(0,a.jsx)(y,{size:20})}),(0,a.jsx)("a",{href:"#",className:"bg-gray-800 p-3 rounded-full text-white hover:bg-gray-700 transition-transform transform hover:scale-110",children:(0,a.jsx)(x,{size:20})})]}),(0,a.jsx)("p",{className:"text-sm text-gray-500 mt-6 md:mt-0",children:"\xa9 2025 ShieldBot. All rights reserved."})]});var v=r(59516),w=r(95797),j=r(54179),k=r(98436);let N=()=>(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)(w.default,{}),(0,a.jsx)(j.default,{}),(0,a.jsx)(v.default,{}),(0,a.jsx)(s.default,{}),(0,a.jsx)(n.default,{}),(0,a.jsx)(k.default,{}),(0,a.jsx)(b,{})]})},99423:(e,t,r)=>{"use strict";r.d(t,{default:()=>a});let a=(0,r(46760).registerClientReference)(function(){throw Error("Attempted to call the default export of \"D:\\\\VAIBHAV\\\\shieldbot\\\\src\\\\components\\\\Faq.jsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"D:\\VAIBHAV\\shieldbot\\src\\components\\Faq.jsx","default")},72322:(e,t,r)=>{"use strict";r.d(t,{default:()=>a});let a=(0,r(46760).registerClientReference)(function(){throw Error("Attempted to call the default export of \"D:\\\\VAIBHAV\\\\shieldbot\\\\src\\\\components\\\\Features.jsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"D:\\VAIBHAV\\shieldbot\\src\\components\\Features.jsx","default")},59516:(e,t,r)=>{"use strict";r.d(t,{default:()=>a});let a=(0,r(46760).registerClientReference)(function(){throw Error("Attempted to call the default export of \"D:\\\\VAIBHAV\\\\shieldbot\\\\src\\\\components\\\\Header.jsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"D:\\VAIBHAV\\shieldbot\\src\\components\\Header.jsx","default")},95797:(e,t,r)=>{"use strict";r.d(t,{default:()=>a});let a=(0,r(46760).registerClientReference)(function(){throw Error("Attempted to call the default export of \"D:\\\\VAIBHAV\\\\shieldbot\\\\src\\\\components\\\\Navbar.jsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"D:\\VAIBHAV\\shieldbot\\src\\components\\Navbar.jsx","default")},54179:(e,t,r)=>{"use strict";r.d(t,{default:()=>a});let a=(0,r(46760).registerClientReference)(function(){throw Error("Attempted to call the default export of \"D:\\\\VAIBHAV\\\\shieldbot\\\\src\\\\components\\\\SideBar.jsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"D:\\VAIBHAV\\shieldbot\\src\\components\\SideBar.jsx","default")},98436:(e,t,r)=>{"use strict";r.d(t,{default:()=>a});let a=(0,r(46760).registerClientReference)(function(){throw Error("Attempted to call the default export of \"D:\\\\VAIBHAV\\\\shieldbot\\\\src\\\\components\\\\Team.jsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"D:\\VAIBHAV\\shieldbot\\src\\components\\Team.jsx","default")},39454:(e,t,r)=>{"use strict";r.r(t),r.d(t,{LoadingProvider:()=>n,useLoading:()=>s});var a=r(46760);let n=(0,a.registerClientReference)(function(){throw Error("Attempted to call LoadingProvider() from the server but LoadingProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"D:\\VAIBHAV\\shieldbot\\src\\contexts\\LoadingContext.js","LoadingProvider"),s=(0,a.registerClientReference)(function(){throw Error("Attempted to call useLoading() from the server but useLoading is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"D:\\VAIBHAV\\shieldbot\\src\\contexts\\LoadingContext.js","useLoading")},70440:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>n});var a=r(88077);let n=async e=>[{type:"image/x-icon",sizes:"16x16",url:(0,a.fillMetadataSegment)(".",await e.params,"favicon.ico")+""}]},61135:()=>{},29517:e=>{function t(){return e.exports=t=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var a in r)({}).hasOwnProperty.call(r,a)&&(e[a]=r[a])}return e},e.exports.__esModule=!0,e.exports.default=e.exports,t.apply(null,arguments)}e.exports=t,e.exports.__esModule=!0,e.exports.default=e.exports}};var t=require("../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),a=t.X(0,[638,39,77,914,414,782],()=>r(1777));module.exports=a})();